// get n app

// export const APIURL = "https://dmsupgrade.in/API/";

// export const ImageAPI="https://docs.dmsupgrade.in/API/";


// API url---- for dmsupgrade.in website

export const APIURL = "https://dev.dmsupgrade.in/";

export const ImageAPI="https://docs.dmsupgrade.in/API/";
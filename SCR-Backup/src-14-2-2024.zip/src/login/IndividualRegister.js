import React, { useEffect, useState, useRef } from "react";
import logo from "../Logo_T.png";
import { Link, useNavigate } from "react-router-dom";
import { APIURL } from "../constant";
import axios from "axios";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import { Helmet } from "react-helmet";
import ExportformDynamicField from "../components/ExportformDynamicField";
import background from "../login/img/registration_1.jpg";

const IndividualRegister = () => {
  const navigation = useNavigate();

  const { companies } = ExportformDynamicField();

  const nameRef = useRef(null);
  const emailRef = useRef(null);
  const phoneNumberRef = useRef(null);
  const niuRef = useRef(null);
  const ApplicantRef = useRef(null);
  const addressRef = useRef(null);
  const usernameRef = useRef(null);
  const passwordRef = useRef(null);
  const companynameRef = useRef(null);
  const bpncodeRef = useRef(null);

  const [bankData, setbankdata] = useState({
    name: "",
    emailID: "",
    CompanyName: "",
    phoneNumber: "",
    address: "",
    userName: "",
    password: "",
    ApplicantType: "1",
    IdentificationNumber: "",
    BPNCode: "",
  });

  const [errors, setErrors] = useState({});
  const [emailerror, setemailerror] = useState(false);
  const [registerusertype, setregisterusertype] = useState("1");
  const [applicantTypes, setapplicantTypes] = useState([]);

  const [toastDisplayed, setToastDisplayed] = useState(false);

  const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/;

  // GetApplicantTypes

  const GetApplicantTypes = async () => {
    try {
      const response = await axios.post(APIURL + "Master/GetApplicantTypes");
      if (response.data.responseCode === "200") {
        setTimeout(() => {
          setapplicantTypes(response.data.responseData);
        }, 1000);
      } else {
        setapplicantTypes("");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const filteredList = companies.filter((company) =>
    company?.companyCode
      ?.toLowerCase()
      .includes(bankData?.CompanyName?.toLowerCase())
  );

  // form validation check
  const validateForm = () => {
    let valid = true;
    const newErrors = {};

    const specialCharacterRegex = /[!@#$%^&*(),.?":{}|<>]/;
    const numericRegex = /\d/;

    if (bankData.name === "") {
      newErrors.name = "Full name is required";
      valid = false;
    }
    if (bankData?.emailID === "") {
      newErrors.emailID = "Email is required";
      valid = false;
      // setemailerror(true);
    }
  else if (!emailRegex.test(bankData?.emailID)) {
    newErrors.emailID = "Please enter valid email Id";
    valid = false;
    // setemailerror(true);
  }
    if (registerusertype == 2 && bankData.IdentificationNumber === "") {
      newErrors.niu = "National identification number is required";
      valid = false;
    }
    if (registerusertype == 1 && bankData.BPNCode === "") {
      newErrors.bpncode = "BPN Code is required";
      valid = false;
    }
    if (bankData.ApplicantType === "") {
      newErrors.ApplicantType = "Select User Type";
      valid = false;
    }
    if (bankData.phoneNumber === "") {
      newErrors.phoneNumber = "Contact number is required";
      valid = false;
    } else if (bankData.phoneNumber.length !== 10) {
      newErrors.phoneNumber = "Contact number should be 10 digits only.";
      valid = false;
    }

    if (bankData.address === "") {
      newErrors.address = "Address is required";
      valid = false;
    }
    if (bankData.userName === "") {
      newErrors.userName = "Username is required";
      valid = false;
    }
    if (registerusertype == 1 && bankData.CompanyName === "") {
      newErrors.CompanyName = "Company name is required";
      valid = false;
    }
    if (bankData.password === "") {
      newErrors.password = "Password is required";
      valid = false;
    } else if (bankData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters long";
      valid = false;
    } else if (!specialCharacterRegex.test(bankData.password)) {
      newErrors.password =
        "Password must contain at least one special character";
      valid = false;
    } else if (!numericRegex.test(bankData.password)) {
      newErrors.password = "Password must contain at least one numeric digit";
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  // handel form
  const bankdataChangehandle = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    if (name === 'userName' &&  (value.includes('$') || value.includes('`') || value.includes('|') || value.includes(' ') || value.includes('~') || value.includes(':') || value.includes(',') || value.includes('>') || value.includes('<') || value.includes('(') || value.includes(')') || value.includes('*') || value.includes('&')  || value.includes('%') || value.includes('#')|| value.includes('+') ||   value.includes('?') || value.includes('!') || value.includes(';')) || value.includes('=') || (value.includes('"')) || (value.includes(`'`)) || (value.includes("/")) ) {
           
      const errmesg = value.slice(-1);
      const errmesglast = errmesg[errmesg.length - 1];

      return setErrors({ 
          userName: `Not valid key`,
        });
  }else{
      setErrors({ 
          userName: ``,
        });
  }

  if (name === 'password' && value.includes(' ')) {
     
      const errmesg = value.slice(-1);
      const errmesglast = errmesg[errmesg.length - 1];

      return setErrors({ 
          password: `Space is not valid key`,
        });
  }else{
      setErrors({ 
          password: ``,
        });
  }

    setbankdata((prevState) => ({
      ...prevState,
      [name]: value,
    }));

    // if (emailRegex.test(bankData.emailID.trim())) {
    //   setemailerror(false);
    // }
  };
 
  const handleUsertype = (e) => {
    setregisterusertype(e.target.value);
  };

  // User/UserRegistration
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (validateForm()) {
      // console.log('Form submitted successfully:', bankData);

      await axios
        .post(APIURL + "User/UserRegistration", {
          name: bankData.name,
          emailID: bankData.emailID,
          CompanyName: bankData.CompanyName,
          phoneNumber: bankData.phoneNumber,
          address: bankData.address,
          userName: bankData.userName,
          password: bankData.password,
          ApplicantType: bankData.ApplicantType,
          IdentificationNumber:
            registerusertype == 1 ? "" : bankData.IdentificationNumber,
          BPNCode: registerusertype == 2 ? "" : bankData.BPNCode,
        })
        .then((response) => {
          if (response.data.responseCode === "200") {
            toast.success(response.data.responseMessage);
            setbankdata({
              name: "",
              emailID: "",
              CompanyName: "",
              phoneNumber: "",
              address: "",
              userName: "",
              password: "",
              ApplicantType: "1",
              IdentificationNumber: "",
              BPNCode: "",
            });

            setTimeout(() => {
              if (nameRef.current) nameRef.current.value = "";
              if (emailRef.current) emailRef.current.value = "";
              if (phoneNumberRef.current) phoneNumberRef.current.value = "";
              if (ApplicantRef.current) ApplicantRef.current.value = "";
              if (niuRef.current) niuRef.current.value = "";
              if (addressRef.current) addressRef.current.value = "";
              if (usernameRef.current) usernameRef.current.value = "";
              if (passwordRef.current) passwordRef.current.value = "";
              if (bpncodeRef.current) bpncodeRef.current.value = "";
              if (companynameRef.current) companynameRef.current.value = "";

              navigation("/");
            }, 1000);
          } else {
            if (!toastDisplayed) {
              toast.warning(response.data.responseMessage, { autoClose: 1000 });
            }
            setToastDisplayed(true);
          }
        })
        .catch((error) => {
          console.log(error);
          toast.warning(error);
        });
    } else {
      if (!toastDisplayed) {
        toast.warning("Please fill all fields", { autoClose: 1000 });
      }
      setToastDisplayed(true);
    }
  };

  useEffect(() => {
    GetApplicantTypes();
    if (toastDisplayed) {
      setTimeout(() => {
        setToastDisplayed(false);
      }, 1500);
    }
  }, [toastDisplayed]);

  return (
    <>
      <Helmet>
        {" "}
        <title>Individual Register</title>{" "}
      </Helmet>
      <div className="user_auth">
        <div
          className="user_auth_left"
          style={{ background: `url(${background})` }}
        >
          <div className="logo_uth_user">
            <img src={logo} />
            <h3>Document Management System</h3>

            <p>
              <b>INDIVIDUAL REGISTRATION FORM</b>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            <br />
            <br />
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            </p> 
          </div>
        </div>
        <div className="user_auth_right">
          <div className="register_outer">
            <div className="login_inner">
              {/* <div className="login_inner_header">
            <img src={logo} />
            <h3>Document Management System</h3>
          </div> */}

              <div className="login_form ">
                <h5>Individual REGISTRATION FORM</h5>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="login_form_panel">
                  <div className="form-bx-radio mb-4">
                    {applicantTypes.map((item, index) => {
                      return (
                        <>
                          <label
                            key={index}
                            className={item.id === 3 ? "d-none" : ""}
                          >
                            <input
                              type="radio"
                              ref={ApplicantRef}
                              onChange={(e) => {
                                handleUsertype(e);
                                bankdataChangehandle(e);
                              }}
                              name="ApplicantType"
                              value={item.id}
                              checked={registerusertype == item.id}
                            />{" "}
                            <span>{item.name}</span>
                          </label>
                        </>
                      );
                    })}
                    {errors.niu && bankData.ApplicantType === "" ? (
                      <small className="errormsg">{errors.ApplicantType}</small>
                    ) : (
                      ""
                    )}
                  </div>

                  {registerusertype == 1 ? (
                    <div className="form-bx mb-3 text-start">
                      <label>
                        <input
                          type="text"
                          ref={companynameRef}
                          value={bankData.CompanyName}
                          className={
                            errors.CompanyName && bankData.CompanyName == ""
                              ? "error"
                              : ""
                          }
                          name="CompanyName"
                          placeholder="Company Name"
                          onChange={(e) => {
                            bankdataChangehandle(e);
                          }}
                          autocomplete="off"
                        />
                        <span className="sspan"></span>
                      </label>
                      <small
                        className={
                          errors.CompanyName && bankData.CompanyName == ""
                            ? "informgserr"
                            : "informgs"
                        }
                      >
                        Please provide at least 3 characters for auto search of company name.
                      </small>
                      {/* {errors.companyname && bankData.companyname == '' ? <small className='errormsg'>{errors.companyname}</small> : ""} */}
                      <ul
                        className={
                          bankData.CompanyName != "" && filteredList
                            ? "filterbx"
                            : "d-none"
                        }
                      >
                        {bankData.CompanyName != ""
                          ? filteredList?.map((cur) => {
                              return (
                                <li>
                                  <button
                                    name="CompanyName"
                                    onClick={(e) => {
                                      bankdataChangehandle(e);
                                    }}
                                    value={cur.companyName}
                                  >
                                    {cur.companyName}
                                  </button>
                                </li>
                              );
                            })
                          : ""}
                      </ul>
                    </div>
                  ) : (
                    ""
                  )}

                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-bx mb-4">
                        <label>
                          <input
                            type="text"
                            ref={nameRef}
                            className={
                              errors.name && bankData.name == "" ? "error" : ""
                            }
                            name="name"
                            placeholder="Full Name"
                            onChange={(e) => {
                              bankdataChangehandle(e);
                            }}
                          />
                          <span className="sspan"></span>
                        </label>
                        {errors.name && bankData.name == "" ? (
                          <small className="errormsg">{errors.name}</small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>

                    <div className="col-md-6">
                      <div className="form-bx mb-4">
                        <label>
                          <input
                            type="text"
                            ref={emailRef}
                            className={
                              errors.emailID  
                                ? "error"
                                : ""
                            }
                            name="emailID"
                            onChange={(e) => {
                              bankdataChangehandle(e);
                            }}
                            placeholder="Email Address"
                          />
                          <span className="sspan"></span>
                        </label>
                        {errors.emailID ? (
                          <small className="errormsg">{errors.emailID}</small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-bx mb-4">
                    <label>
                      <input
                        type="number"
                        ref={phoneNumberRef}
                        min={0}
                        maxLength={10}
                        className={errors.phoneNumber ? "error" : ""}
                        name="phoneNumber"
                        onChange={(e) => {
                          bankdataChangehandle(e);
                        }}
                        placeholder="Contact Number"
                      />
                      <span className="sspan"></span>
                    </label>
                    {errors.phoneNumber ? (
                      <small className="errormsg">{errors.phoneNumber}</small>
                    ) : (
                      ""
                    )}
                  </div>

                  <div className="form-bx mb-4">
                    <label>
                      <input
                        type="text"
                        ref={addressRef}
                        className={
                          errors.address && bankData.address == ""
                            ? "error"
                            : ""
                        }
                        name="address"
                        onChange={(e) => {
                          bankdataChangehandle(e);
                        }}
                        placeholder="Address"
                      />
                      <span className="sspan"></span>
                    </label>
                    {errors.address && bankData.address == "" ? (
                      <small className="errormsg">{errors.address}</small>
                    ) : (
                      ""
                    )}
                  </div>

                  {registerusertype == 2 ? (
                    <div className="form-bx mb-4">
                      <label>
                        <input
                          type="number"
                          ref={niuRef}
                          className={
                            errors.niu && bankData.IdentificationNumber == ""
                              ? "error"
                              : ""
                          }
                          name="IdentificationNumber"
                          placeholder="National Identification Number"
                          onChange={(e) => {
                            bankdataChangehandle(e);
                          }}
                        />
                        <span className="sspan"></span>
                      </label>
                      {errors.niu && bankData.IdentificationNumber == "" ? (
                        <small className="errormsg">{errors.niu}</small>
                      ) : (
                        ""
                      )}
                    </div>
                  ) : (
                    ""
                  )}

                  {registerusertype == 1 ? (
                    <div className="form-bx mb-4">
                      <label>
                        <input
                          type="number"
                          ref={bpncodeRef}
                          className={
                            errors.bpncode && bankData.BPNCode == ""
                              ? "error"
                              : ""
                          }
                          name="BPNCode"
                          placeholder="BPN Code"
                          onChange={(e) => {
                            bankdataChangehandle(e);
                          }}
                        />
                        <span className="sspan"></span>
                      </label>
                      {errors.bpncode && bankData.BPNCode == "" ? (
                        <small className="errormsg">{errors.bpncode}</small>
                      ) : (
                        ""
                      )}
                    </div>
                  ) : (
                    ""
                  )}

                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-bx mb-4">
                        <label>
                          <input
                            type="text"
                            ref={usernameRef}
                            className={
                              errors.userName && bankData.userName == ""
                                ? "error"
                                : ""
                            }
                            name="userName"
                            onChange={(e) => {
                              bankdataChangehandle(e);
                            }}
                            placeholder="Username"
                            value={bankData.userName}
                          />
                          <span className="sspan"></span>
                        </label>
                        {errors.userName   ? (
                          <small className="errormsg">{errors.userName}</small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-bx mb-3">
                        <label>
                          <input
                            type="password"
                            ref={passwordRef}
                            className={errors.password ? "error" : ""}
                            name="password"
                            onChange={(e) => {
                              bankdataChangehandle(e);
                            }}
                            placeholder="Password"
                            value={bankData.password}
                          />
                          <span className="sspan"></span>
                        </label>
                        {errors.password ? (
                          <small className="errormsg">{errors.password}</small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-footer">
                    <Link to="/" className="register">
                      Login
                    </Link>
                    <button className="login">Signup</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default IndividualRegister;

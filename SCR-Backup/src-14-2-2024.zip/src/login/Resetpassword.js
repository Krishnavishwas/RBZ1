import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { APIURL } from "../constant";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const Resetpassword = () => {
  const emailRef = useRef(null);

  const navigate = useNavigate();

  const [email, setemail] = useState("");

  const [Closemodle, setClosemodle] = useState(false);

  const [errors, setErrors] = useState(false);
  const [toastDisplayed, setToastDisplayed] = useState(false);

  const submitForm = (e) => {
    e.preventDefault();

    if (email != "") {
     axios
        .post(APIURL + "User/ForgotPassword", { userName: email })
        .then((res) => {
            console.log("resetpass", res)
          if (res.data.responseCode === "200") {
            setToastDisplayed(true);
            setClosemodle(true);
            setemail();
            if (emailRef.current) emailRef.current.value = "";

            toast.success(res.data.responseMessage);
            localStorage.setItem("resetpasswordtoken", res.data.responseData.token);

           
          } else {
            setToastDisplayed(true);
            toast.warning("Username is wrong", { autoClose: 1000 });
          }
        })
        .catch((err) => {
          toast.error(err);
        });
    } else {
      setErrors(true);
    }
  };

  useEffect(() => {
    if (Closemodle) { 
        navigate("/");
    }
}, [Closemodle]);


  console.log("Closemodle", Closemodle)

  useEffect(() => {
    if (toastDisplayed) {
      setTimeout(() => {
        setToastDisplayed(false);
      }, 1500);
    }
  }, [toastDisplayed]);

  return (
    <>
    {
      Closemodle !== true ?  (<div className="modal fade" id="verticalycentered" tabindex="-1">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-body">
            <div className="modalheader">
              <h5 className="modal-title">Forgot Password!</h5>
              <p>Please provide your username:</p>
            </div>

            <div className="form-bx mb-5">
              <label>
                <input
                  type="text"
                  ref={emailRef}
                  placeholder="Username"
                  className={errors === true && !email ? "error" : ""}
                  onChange={(e) => {
                    setemail(e.target.value);
                  }}
                />
                <span className="sspan"></span>
              </label>
              {errors === true && !email ? (
                <small class="errormsg">Username is Required</small>
              ) : (
                ""
              )}
            </div>

            <div className="modalfooter">
              <button
                type="button"
                className="register"
                data-bs-dismiss="modal"
              >
                Close
              </button>

              {Closemodle === true ? (
                <button
                  type="button"
                  className="login "
                  data-bs-dismiss="modal"
                  onClick={(e) => {
                    submitForm(e);
                  }}
                  disabled={toastDisplayed ? true : false}
                >
                  {toastDisplayed ? "Please wait.." : "Ok"}
                </button>
              ) : (
                <button
                  type="button"
                  className="login "
                  onClick={(e) => {
                    submitForm(e);
                  }}
                  disabled={toastDisplayed ? true : false}
                >
                  {toastDisplayed ? "Please wait..." : "Ok"}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>)
    :""
    }
    </>
  );
};

export default Resetpassword;

import React from 'react'
import { Link } from "react-router-dom";
import { Helmet } from 'react-helmet';
import AdminDashboardLayout from '../components/AdminDashboardLayout';

const AdminHome = () => {
  return (
    <>
      <Helmet>  <title>Dashboard</title>  </Helmet>
      <AdminDashboardLayout>
        <nav>
          <ol className="breadcrumb">
            <li className="breadcrumb-item"><a href="index.html">Home</a></li>
            <li className="breadcrumb-item active">Dashboard</li>
          </ol>
        </nav>
        <div className="pagetitle">
          <h1>Admin Dashboard <span>EXPORTS</span></h1>
          <nav>
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><a>Exports</a></li>
            </ol>
          </nav>
        </div>

        <section className="section dashboard">

         
          <div className='row'>
            <div className='col-md-12'>
              <div className='datatable'>
                <h4 className='section_top_heading'>SUBMITTED REQUESTS</h4>

                <p>Admin Dashboard Page</p>

              </div>
            </div>
          </div>

        </section>
      </AdminDashboardLayout>
    </>
  )
}

export default AdminHome

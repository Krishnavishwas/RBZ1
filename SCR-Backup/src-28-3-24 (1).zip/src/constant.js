export const APIURL = "https://dmsupgrade.in/API/";

export const ImageAPI="http://docs.dmsupgrade.in/API/";


// export const APIURL = "http://localhost:5109/";

import React, { useState, useRef, useEffect } from "react";
import DataTable from "react-data-table-component";
import { CSVLink } from "react-csv";
import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";
import { Link } from 'react-router-dom'
import { APIURL } from "../../constant";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { toast } from 'react-toastify';

const ApprovedUserTable = () => {

    const [searchText, setSearchText] = useState("");
    const [tableData, setTableData] = useState([]);
    const [toastDisplayed, setToastDisplayed] = useState(false);
    const [formerr, setformerr] = useState();
    const [updateerr, setupdateerr] = useState();
    const csvLinkRef = useRef();
    const [errors, setErrors] = useState(false);
    const handleClick = (title) => {
        alert(`Title: ${title}`);
    };


    // GovernmentAgency update start

    const [showUpdateModal, setShowUpdateModal] = useState(false);
    const UpdateModalClose = () => {
        setShowUpdateModal(false);
        setUpdateData({
            agencyName: '',
            status: '',

        })
        setupdateerr('');
    }
    const [updateData, setUpdateData] = useState({

        name: '',
        emailID: '',
        phoneNumber: '',
        address: '',
        identificationNumber: '',
        applyingFor: '',
        status: '',

    })

    const [depValue, setDepValue] = useState([])
    const [userGrpValue, setUserGrpValue] = useState([])


    const changeUpdateForm = (e) => {

        const { name, value } = e.target;
        let newErrors = {};

        const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
        const spaceCheck = /\s{2,}/g;
        if (name == "agencyName" && specialChars.test(value)) {
            newErrors.agencyName = "Special characters not allowed";
        } else if (name == "agencyName" && value.charAt(0) === ' ') {
            newErrors.agencyName = "First character cannot be a blank space";
        } else if (name == "agencyName" && spaceCheck.test(value)) {
            newErrors.agencyName = "Multiple space not allow";
        }

        else {

            setUpdateData((prevState) => ({
                ...prevState,
                [name]: value

            }));
        }
        setupdateerr(newErrors);

    }
    //on chnage usergrp value
    const changeDptFrom = (e) => {
        const value = e.target.value;

        const isChecked = e.target.checked
        if (isChecked) {
            //Add checked item into checkList
            setDepValue([...depValue, value]);
        }
        else {
            //Remove unchecked item from checkList
            const filteredList = depValue.filter((item) => item !== value);
            setDepValue(filteredList);
        }

    }
    //on chnage department value
    const changeUserGrpFrom = (e) => {
        const value = e.target.value;

        const isChecked = e.target.checked
        if (isChecked) {
            //Add checked item into checkList
            setUserGrpValue([...userGrpValue, value]);
        } else {
            //Remove unchecked item from checkList
            const filteredList = userGrpValue.filter((item) => item !== value);
            setUserGrpValue(filteredList);
        }

    }

    const [updateID, setUpdateID] = useState("")
    const handleUpdate = async (id) => {

        setShowUpdateModal(true);
        setUpdateID(id)
        const TableId = {
            "UserID": id
        }

        try {
            const response = await fetch(APIURL + 'User/GetUserDetailsByUserID', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(TableId)
            });

            const data = await response.json();
            setUpdateData(data.responseData)

        } catch (error) {
            console.error('Error fetching data:', error);
        }

    }

    const [depData, setDepData] = useState([]);
    const [userGrp, setUserGrp] = useState([]);
    // Associated Department api start 
    const dep_data = async () => {
        try {
            const responce = await fetch(APIURL + 'Admin/GetAllMenu', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
            });
            const data = await responce.json();
            setDepData(data.responseData)

        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }


    // Associated Department api end 
    // user Grp api start 
    const userGrp_data = async () => {
        try {
            const responce = await fetch(APIURL + 'Master/GetMasterRoles', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
            });
            const data = await responce.json();
            setUserGrp(data.responseData)

        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
    // user Grp api end 
    const handleUpdateData = async () => {
        //console.log("updateData",updateData);

        const updateValue = {
            "ID": updateData.id,
            "Name": updateData.name,
            "RBZReferenceNumber": updateData.applyingFor,
            "EmaiId": updateData.emailID,
            "PhoneNumber": updateData.phoneNumber,
            "Address": updateData.address,
            "IdentificationNumber": updateData.identificationNumber,
            "UserID": updateID,
            "Status": updateData.status,
           "MenuID" :depValue,
           "RoleID":userGrpValue
        }
        console.log("updateValue", updateValue);
        // try {
        //     if (isUpdateValid()) {
        //         const response = await fetch(APIURL + 'Admin/UpdateGovtAgency', {
        //             method: "POST",
        //             headers: {
        //                 "Content-Type": "application/json",
        //             },
        //             body: JSON.stringify(updateValue)
        //         });

        //         const data = await response.json();
        //         setToastDisplayed(true)
        //         if (data.responseCode === '200') {

        //             setErrors(false)

        //             toast.success(data.responseMessage, { autoClose: 2000 })
        //             setTimeout(() => {
        //                 UpdateModalClose();
        //                 table_Data();
        //                 setUpdateData({
        //                     agencyName: '',
        //                 })
        //               setSearchText('');
        //                 setToastDisplayed(false)
        //             }, 2500)
        //         }
        //         else {
        //             toast.warning(data.responseMessage, { autoClose: 2000 })
        //             setTimeout(() => {

        //                 table_Data();
        //                 setToastDisplayed(false);

        //             }, 2500)
        //         }
        //     }

        // } catch (error) {
        //     console.error('Error fetching data:', error);
        // }

    }
    // approve update end



    // approve user list api start 
    const table_Data = async () => {
        try {
            const response = await fetch(APIURL + 'User/GetActiveInactiveUsers', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
            });
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            setTableData(data.responseData)

        } catch (error) {
            console.error('Error fetching data:', error);
        }

    }
    // approve list api end
    useEffect(() => {
        table_Data();
        dep_data();
        userGrp_data()
    }, [])
    const columns = [

        // {
        //     name: 'ID',
        //     selector: row => row.id,
        //     sortable: true,
        //     searchable: true,
        //     width: '10%',
        // },
        {
            name: 'User Name',
            selector: row => row.name,
            sortable: true,
            searchable: true,
            width: '25%',
        },
        {
            name: 'Email Address',
            selector: function (row) {
                return row.emailID ? row.emailID : "_"
            },
            sortable: true,
            searchable: true,
            width: '25%',
        },
        {
            name: 'Contact Number',
            selector: function (row) {
                return row.phoneNumber ? row.phoneNumber : "_"
            },
            sortable: true,
            searchable: true,
            width: '20%',
        },
        {
            name: 'Registration Type',
            selector: function (row) {
                return row.applyingFor ? row.applyingFor : "_"
            },
            sortable: true,
            searchable: true,
            width: '20%',
        },

        {
            name: 'Action',
            width: '10%',
            cell: row => <> <Link to="" className="me-2"
                onClick={() => handleUpdate(row.userID)}><i class="bi bi-pencil-square"></i></Link>


            </>
        },

    ];

    // validation update start
    const isUpdateValid = () => {
        const newErrors = {};
        let valid = true

        if (!updateData.agencyName) {
            newErrors.agencyName = "Goverment agency name is required";
            valid = false
        }


        setupdateerr(newErrors);
        return valid;


    }

    // application form end
    const filteredData = tableData?.filter(item =>
    (item.agencyName?.toLowerCase().includes(searchText.toLowerCase()) ||
        (item.id && item.id.toString().includes(searchText)) ||
        (item.status == "1" ? "Active" : "Inactive").toLowerCase().includes(searchText?.toLowerCase()))

    );


    // const handleExportExcel = () => {
    //     const worksheet = XLSX.utils.json_to_sheet(filteredData);
    //     const workbook = XLSX.utils.book_new();
    //     XLSX.utils.book_append_sheet(workbook, worksheet, "Movie Data");
    //     const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    //     const excelData = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    //     FileSaver.saveAs(excelData, "movie_data.xlsx");
    // };



    return (
        <>
            <>
                <DataTable
                    columns={columns}
                    data={filteredData}
                    pagination

                    defaultSortFieldId={1}
                    defaultSortAsc={false}
                    paginationRowsPerPageOptions={[10, 50, 100]}
                    highlightOnHover
                    dense
                    striped
                    fixedHeader
                    subHeader
                    subHeaderComponent={
                        <div className="admintablesearch">
                            <div className="tablesearch_bx">
                                <input
                                    type="text"
                                    placeholder="Search"
                                    value={searchText}
                                    onChange={(e) => setSearchText(e.target.value)}
                                />
                            </div>
                            <div className="table-btn-bx">
                                {/* <CSVLink
                                data={filteredData}
                                filename={"movie_data.csv"}
                                className="hidden"
                                ref={csvLinkRef} 
                            >
                                Export to CSV
                            </CSVLink> */}
                                {/* <button onClick={handleExportExcel} disabled>Export to Excel</button> */}
                                {/* <Button
                                    onClick={handleFormShow}
                                >
                                    Add Government Agency
                                </Button> */}
                            </div>

                        </div>
                    }
                />

            </>


            {/* Approve USer Form update modal */}
            <Modal show={showUpdateModal} onHide={UpdateModalClose} backdrop="static">
                <div className="application-box editmodal-change">
                    <div className="login_inner">
                        <div class="login_form "><h5>
                            <Modal.Header closeButton className="p-0">
                                <Modal.Title>Update Approve User</Modal.Title>
                            </Modal.Header>
                        </h5></div>
                        <div className="login_form_panel">
                            <Modal.Body className="p-0">
                                <div className="form-bx mb-4">
                                    <p className="form-label">User Name</p>
                                    <label>
                                        <input type="text" name="name" className='formcontrol' disabled placeholder="User Name" onChange={(e) => { changeUpdateForm(e) }} required value={updateData?.name} />
                                        <span className='sspan'></span>
                                    </label>
                                    {updateerr?.name ? (
                                        <span className="errormsg">
                                            {updateerr?.name}
                                        </span>
                                    ) : ""}
                                </div>
                                <div className="form-bx mb-4">
                                    <p className="form-label">Email Address</p>
                                    <label>
                                        <input type="email" name="emailID" className='formcontrol' disabled placeholder="Email Address" onChange={(e) => { changeUpdateForm(e) }} required value={updateData?.emailID} />
                                        <span className='sspan'></span>
                                    </label>
                                    {updateerr?.emailID ? (
                                        <span className="errormsg">
                                            {updateerr?.emailID}
                                        </span>
                                    ) : ""}
                                </div>
                                <div className="form-bx mb-4">
                                    <p className="form-label">Address</p>
                                    <label>
                                        <textarea name="address" className='formcontrol' disabled placeholder="Address" onChange={(e) => { changeUpdateForm(e) }} required value={updateData?.address}></textarea>
                                    </label>
                                    {updateerr?.address ? (
                                        <span className="errormsg">
                                            {updateerr?.address}
                                        </span>
                                    ) : ""}
                                </div>
                                <div className="form-bx mb-4">
                                    <p className="form-label">Contact Number</p>
                                    <label>
                                        <input type="number" name="phoneNumber" className='formcontrol' disabled placeholder="Contact Number" onChange={(e) => { changeUpdateForm(e) }} required value={updateData?.phoneNumber} />
                                        <span className='sspan'></span>
                                    </label>
                                    {updateerr?.phoneNumber ? (
                                        <span className="errormsg">
                                            {updateerr?.phoneNumber}
                                        </span>
                                    ) : ""}
                                </div>
                                <div className="form-bx mb-4">
                                    <p className="form-label">National Identifier Number</p>
                                    <label>
                                        <input type="text" name="identificationNumber" className='formcontrol' disabled placeholder="National Identifier Number" onChange={(e) => { changeUpdateForm(e) }} required value={updateData?.identificationNumber} />
                                        <span className='sspan'></span>
                                    </label>
                                    {updateerr?.identificationNumber ? (
                                        <span className="errormsg">
                                            {updateerr?.identificationNumber}
                                        </span>
                                    ) : ""}
                                </div>
                                <div className="form-bx mb-4">
                                    <p className="form-label">Registration Type</p>
                                    <label>
                                        <input type="text" name="applyingFor" className='formcontrol' disabled placeholder="Registration Type" onChange={(e) => { changeUpdateForm(e) }} required value={updateData?.applyingFor} />
                                        <span className='sspan'></span>
                                    </label>
                                    {updateerr?.applyingFor ? (
                                        <span className="errormsg">
                                            {updateerr?.applyingFor}
                                        </span>
                                    ) : ""}
                                </div>
                                <div className="form-bx mb-4">
                                    <p className="form-label">Select Status</p>
                                    <label>
                                        <select name="status" class="" aria-label="Large select example" onChange={(e) => { changeUpdateForm(e) }} value={updateData?.status}>
                                            <option value="30">Pending</option>
                                            <option value="10">Approve</option>
                                            <option value="20">Reject</option>
                                        </select>
                                        <span className='sspan'></span>
                                    </label>
                                </div>
                                <div className="form-bx mb-4">
                                    <p className="form-label">Associated Department</p>
                                    <div className="checkbox-Box">
                                        {
                                            depData?.map((item, index) => {
                                                // console.log("depData9999",index);
                                                return (
                                                    <div className="deptInner-box d-flex mb-2" key={index}>
                                                        <input type="checkbox" id={item.menuName} name={item.menuName} value={item.id} onChange={(e) => { changeDptFrom(e) }} />
                                                        <span for={item.menuName}>{item.menuName}</span>
                                                    </div>
                                                )
                                            })
                                        }
                                        {/* <div className="deptInner-box d-flex mb-2">
                                            <input type="checkbox" id="import" name="import" value="import" />
                                            <span for="import">Import</span>
                                        </div> */}

                                    </div>
                                </div>
                                <div className="form-bx mb-4">
                                    <p className="form-label">Select User Group</p>
                                    <div className="checkbox-Box">
                                        {
                                            userGrp?.map((item) => {
                                                return (
                                                    <div className="deptInner-box d-flex mb-2" >
                                                        <input type="checkbox" id={item.designation} name={item.designation} value={item.id} onChange={(e) => { changeUserGrpFrom(e) }} />
                                                        <span for={item.designation}>{item.designation}</span>
                                                    </div>
                                                )
                                            })
                                        }
                                        {/* <div className="deptInner-box d-flex mb-2">
                                            <input type="checkbox" id="IndividualORCompany" name="IndividualORCompany" value="IndividualORCompany" />
                                            <span for="IndividualORCompany">IndividualORCompany</span>
                                        </div> */}

                                    </div>
                                </div>
                            </Modal.Body>
                            <Modal.Footer className="p-0">
                                <Button variant="primary" onClick={handleUpdateData} disabled={toastDisplayed ? true : false}>
                                    Update
                                </Button>
                            </Modal.Footer>
                        </div>
                    </div>
                </div>
            </Modal>
        </>
    )
}

export default ApprovedUserTable

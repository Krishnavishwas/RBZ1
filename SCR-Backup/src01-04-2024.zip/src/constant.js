export const APIURL = "https://dmsupgrade.in/API/";

export const ImageAPI="https://docs.dmsupgrade.in/API/";


// export const APIURL = "http://localhost:5109/";

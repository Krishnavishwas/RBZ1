import React, { useEffect, useState } from "react";
import logo from "../Logo_T.png";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import AuthUser from "./AuthUser";
import { APIURL } from "../constant";
import { toast } from "react-toastify";
import Resetpassword from "./Resetpassword";
import { Storage } from "./Storagesetting";
import axios from "axios";

const Login = () => {
  // const navigation = useNavigate();

  const { http, setToken } = AuthUser();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [checkloader, setCheckloader] = useState(false);
  const [errors, setErrors] = useState({});


  const [ipAddress, setIpAddress] = useState(null);


  useEffect(() => {
    const fetchIpAddress = async () => {
      try {
        const response = await axios.get('https://api.ipify.org?format=json');
       
        const newIpAddress = response.data.ip;

        setIpAddress(newIpAddress)
        
      } catch (error) {
        console.error('Error fetching IP address:', error);
      }
    };

    fetchIpAddress();
  }, []);


  // form validation check
  const validateForm = () => {
    let valid = true;
    const newErrors = {};

    if (email === "") {
      newErrors.email = "Email Name is Required";
      valid = false;
    }
    if (password === "") {
      newErrors.password = "Password is required or invalid";
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const submitForm = () => {
    if (validateForm()) {
      setCheckloader(true);
      http
        .post(APIURL + "User/UserLogin", {
          userName: email,
          password: password,
          IPAddress:ipAddress
        })
        .then((res) => {  
          if (res.data.responseCode === "200") { 
            setToken(
              res.data.responseData.userType,
              res.data.responseData.loginToken,
              res.data.responseData.userID,
              res.data.responseData.userName,
              res.data.responseData.applicantType,
              res.data.responseData.name,
              res.data.responseData.roleID,
              res.data.responseData.roleName,
              res.data.responseData.bankID,
              ipAddress
            );
          } else {
            toast.error(" Please check and enter the correct Username.", {
              autoClose: 1000,
            });
            setErrors({
              email: "",
              password: `The Username Provided by you doesn't seem to exist in the System. Please check and enter the correct Username.`,
            });

            setTimeout(() => {
              setCheckloader(false);
            }, 1500);
          }
        });
    }
  };


  const handleKeyDown = (event) => {
    if (event.key === 'Enter') { 
      submitForm();
    }
  };

  return (
    <>
      <Helmet>
        {" "}
        <title>Login</title>{" "}
      </Helmet>

      <div className="login_outer">
        <div className="login_inner">
          <div className="login_inner_header">
            <img src={logo} />
            <h3>Document Management System</h3>
          </div>

          <div className="login_form ">
            <h5>LOGIN FORM</h5>
          </div>

          <div className="login_form_panel">
            <div className="form-bx mb-5">
              <label>
                <input
                  type="email"
                  className={
                    errors?.email ? "form-control error" : "form-control"
                  }
                  placeholder="Enter email"
                  onChange={(e) => {
                    setEmail(e.target.value);
                  }}
                  id="email"
                  onKeyDown={handleKeyDown} 
                />

                <span className="sspan"></span>
              </label>
              {errors?.email ? (
                <small className="errormsg">{errors?.email}</small>
              ) : (
                ""
              )}
            </div>
            <div className="form-bx">
              <label>
                <input
                  type="password"
                  className={
                    errors?.password ? "form-control error" : "form-control"
                  }
                  placeholder="Enter password"
                  onChange={(e) => {
                    setPassword(e.target.value);
                  }}
                  id="pwd"
                  onKeyDown={handleKeyDown} 
                />
                <span className="sspan"></span>
              </label>
              {errors?.password ? (
                <small className="errormsg2">{errors?.password}</small>
              ) : (
                ""
              )}
            </div>

            <div className="form-bx mt-5">
              <Link
                to=""
                data-bs-toggle="modal"
                data-bs-target="#verticalycentered"
              >
                Forgot password?
              </Link>
            </div>

            <div className="form-footer">
              <Link to="/usertype" className="register">
                Register
              </Link>
              <button
                className="login"
                type="button"
                onClick={(e) => submitForm(e)}
                disabled={checkloader === true ? true : false}
                onKeyDown={handleKeyDown} 

              >
                {checkloader === true ? "Please Wait.." : "Login"}
              </button>
            </div>
          </div>
        </div>
      </div>

      <Resetpassword />
    </>
  );
};

export default Login;

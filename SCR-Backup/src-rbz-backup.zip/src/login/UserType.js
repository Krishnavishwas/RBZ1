import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import logo from "../Logo_T.png" 
import {APIURL} from '../constant'
import axios from 'axios' 
import 'react-toastify/dist/ReactToastify.css';
import { Helmet } from 'react-helmet'

const UserType = () => {

  const [userData, setUserdata]= useState([]);


  const getHandledata = async () => {
    await axios
      .post(APIURL + 'Master/getusertypes')
      .then((response) => {   
        if(response.data.responseCode === "200"){
          setTimeout(() => {
            setUserdata(response.data.responseData )
          }, 1000);
        }else{
          setUserdata([]) 
        }
        
      })
      .catch((error) => {
        console.log(error);
      });
  };
  

  useEffect(()=>{
    getHandledata();
  },[])


  return (
    <>
      <Helmet>  <title>User-Type</title>  </Helmet>
      
    <div className='login_outer'>
        <div className='register_header'>
            <Link to='/'>
            <img src={logo} /></Link>
    <h3>Document Management System / Registration Types</h3>
            
            <div className='registration_form_panel_outer'> 

{
  userData.length ? userData.map((item, index)=>{
    return(
      <div className='registration_form_panel' key={item.id}>
      <h5>{item.name}</h5>

      <p>
      {  item.description }
      </p>

      <div class="form-footer"><Link to='/' class="register">Back</Link>
      <Link to={item.id == 1 ? '/IndividualRegister' : item.id == 2 ? '/BankRegister' : '/GovAgencieRegister' } class="login">Register</Link>
      </div>
    </div>
    )
  }) :  <span class="loader"></span>
}
             




              {/* ----------------- */}

              {/* <div className='registration_form_panel'>
                <h5>AUTHORISED DEALERS/ADLA REGISTRATIONS</h5>

                <p>
                Registration of system users belonging to Authorized Dealers (ADs) or Authorized Dealers with Limited Authority (ADLAs) responsible for processing and submitting Exchange control requests on behalf of their clients.
                </p>

                <div class="form-footer"><Link to='/' class="register">Back</Link><Link to='/BankRegister' class="login">Register</Link></div>
              </div>

              <div className='registration_form_panel'>
                <h5>GOVERNMENT AGENCIES/INSTITUTIONS REGISTRATIONS</h5>

                <p>
                Registration of system users belonging to Government Agencies/Regulatory Bodies which assist Exchange Control in monitoring compliance with Exchange Control regulations.
                </p>

                <div class="form-footer"><Link to='/' class="register">Back</Link><Link to='/GovAgencieRegister' class="login">Register</Link></div>
              </div> */}
            </div>
        </div>
    </div>

    </>
  )
}

export default UserType

import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import { APIURL } from '../constant';
import { Storage } from '../login/Storagesetting';

const Sidebar = () => {

  const roleIDs = Storage.getItem('roleIDs');
  const LoginToken = Storage.getItem('loginToken');
  const UserID =  Storage.getItem('userID');
 
  const [menuItem, setmenuItem]= useState([])

  

const getMenudata = async ()=>{ 
 
  try{
    const response = await axios.post(APIURL + 'Master/GetMenuData',{
      RoleID:roleIDs.toString(),
      LoginToken:LoginToken,
      UserID:UserID
    });
 
    if(response.data.responseCode === '200'){
      console.log("response.data.responseData", response.data.responseData)
      setmenuItem(response.data.responseData)
    }else{
      setmenuItem([])
    }

  } 
  catch(err){
    console.log(err)
  }
}
 

useEffect(()=>{
  getMenudata();
},[])



const currentUrl = window.location.href;
const urlParts = currentUrl.split('/');
const lastUrlPart = urlParts[urlParts.length - 1];
 
 

  return (
   
    <aside id="sidebar" className="sidebar">
      <h6 className="quicklaunch">
        <span>QUICK LAUNCH</span>
      </h6>

      <ul className="sidebar-nav" id="sidebar-nav"> 
      <li className="nav-item activemenu">
          <Link className="nav-link" to="/BankADLADashboard">
            <i className="bi bi-house-fill"></i>
            <span>Home</span>
          </Link>
        </li>

        {
          menuItem?.map((items, index)=>{
            return(
              <>
              <li className="nav-item" key={index}>
          {/* <Link className="nav-link collapsed" data-bs-target={"#"+items.menuName.replace(/\s/g, '')} data-bs-toggle="collapse" to={'/'+items.subMenuURL}>
            <i className="bi bi-arrow-up-right-square-fill"></i><span>{items.menuName}</span><i className="bi bi-chevron-down ms-auto"></i>
          </Link> */}

<Link className="nav-link ">
            <i className="bi bi-arrow-up-right-square-fill"></i><span>{items.menuName}</span>
          </Link>
          <ul  className="nav-content  " >
         {
           items?.subMenu?.map((submenuitem, subindex)=>{
            return(
             
            <li  key={subindex} className={lastUrlPart == submenuitem.subMenuURL ? 'activemenu' : ''}>
              <Link to={"/"+ submenuitem.subMenuURL}>
                <i className={'bi ' + submenuitem.subMenuIcon}></i><span>{submenuitem.subMenuName}</span>
              </Link>
            </li>
       
            )
           })
         } 
              </ul>

          </li>
              </>
            )
          })
        }

       

      </ul>

    </aside>
  )
}

export default Sidebar

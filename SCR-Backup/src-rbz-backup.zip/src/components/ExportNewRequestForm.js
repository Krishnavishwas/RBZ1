import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import ExportformDynamicField from './ExportformDynamicField'

const ExportNewRequestForm = () => {

    const { currency, companies, GovernmentAgencies, applicantTypes } = ExportformDynamicField();


    const [exportForm, setExportForm] = useState(
        {
            user: '',
            bankName: '',
            purposeApplication: '',
            typeExporter: '',
            companyName: '',
            applicant: '',
            applicantReferenceNumber:'',
            applicantYear: '',
            applicationDate: '',
            applicationType: '',
            currency: '',
            amount: '',
            rate: '',
            usdEquivalent: '',
            relatedexchangeControlNumber: '',
            sector: '',
            subsector: '',
            applicantComments: '',
            bankSupervisor: ''
        }
    )
    const [registerusertype, setregisterusertype] = useState('1');
    const [files, setFiles] = useState([]);

    const [otherfiles, setOtherfiles] = useState([]);

    const changeHandelForm = (e) => {
        const name = e.target.name;
        const value = e.target.value
        setExportForm((prevState) => ({
            ...prevState,
            [name]: value
        }));
    }

    const handleUsertype = (e) => {
        setregisterusertype(e.target.value)
    }

     
    
      const handleAddMore = () => {
        setOtherfiles([...otherfiles, null]);

      };
 
      const handleFileChange = (e) => {
         const file = e.target.files[0]
         setFiles([...files, file]);
      };

      const filteredCompanyList = companies.filter((company) =>
    company?.companyCode
      ?.toLowerCase()
      .includes(exportForm?.companyName?.toLowerCase())
  );

    console.log("exportForm", exportForm) 
    console.log("companies", companies)
    console.log("GovernmentAgencies", GovernmentAgencies)

    console.log("files", files)

    return (
        <>

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>User</label>

                <div className="form-bx"><label>
                    <input type="text" name="user" placeholder="Bankuser7" onChange={(e) => { changeHandelForm(e) }} disabled />
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Name of Bank</label>

                <div className="form-bx"><label>
                    <select name='bankName' onChange={(e) => { changeHandelForm(e) }}>
                        <option selected="selected" value="48">Access Finance</option>
                        <option value="6">AFC Commercial Bank</option>
                        <option value="5">African Century</option>
                        <option value="7">BancABC</option>
                        <option value="26">Barnfords</option>
                        <option value="33">Bonga Travel</option>
                        <option value="50">CABS</option>
                        <option value="34">Campion Bureau De Change t/a Hand2hand</option>
                        <option value="10">CBZ Bank Limited</option>
                        <option value="9">Central Africa Building Society</option>
                        <option value="43">Contec Global</option>
                        <option value="52">Direct Connect Financial Services</option>
                        <option value="28">Easylink</option>
                        <option value="11">Ecobank Zimbabwe</option>
                        <option value="27">Econet</option>
                        <option value="59">ELIZABETH FLORIST T/A TSD BUREAU DE CHANGE</option>
                        <option value="61">EmpowerBank</option>
                        <option value="57">Exports Department</option>
                        <option value="30">Expressfin</option>
                        <option value="12">FBC Bank Limited</option>
                        <option value="8">First Capital Bank</option>
                        <option value="31">FMC Finance</option>
                        <option value="35">Fredex</option>
                        <option value="13">GetBucks</option>
                        <option value="44">Getbucks</option>
                        <option value="58">Imports Department</option>
                        <option value="65">INDUSIND BANK</option>
                        <option value="14">Infrastructure Development Bank of Zimbabwe</option>
                        <option value="62">Innbucks MicroBank</option>
                        <option value="39">Kaah Express</option>
                        <option value="41">Meikles Financial Services</option>
                        <option value="49">Metbank</option>
                        <option value="16">Metbank*</option>
                        <option value="56">Mosaic Bureau de Change </option>
                        <option value="55">National Building Society</option>
                        <option value="17">National Building Society (NBS)</option>
                        <option value="60">National Payment Systems Department</option>
                        <option value="15">Nedbank Zimbabwe</option>
                        <option value="51">Nissi Global</option>
                        <option value="18">NMB Bank Limited</option>
                        <option value="36">OK Money Wave</option>
                        <option value="19">Peoples Own Savings Bank</option>
                        <option value="40">Quest Financial Services</option>
                        <option value="53">RBZ Retail Banking</option>
                        <option value="20">Reserve Bank of Zimbabwe</option>
                        <option value="37">Send Money Home</option>
                        <option value="38">Simukai Financial Services</option>
                        <option value="32">Solten Financial Services</option>
                        <option value="21">Stanbic Bank Zimbabwe</option>
                        <option value="22">Standard Chartered Bank</option>
                        <option value="23">Steward Bank</option>
                        <option value="54">SUCCESS MICROFINANCE BANK</option>
                        <option value="47">Superdeal Enterprises t/a Kwik Forex Shop</option>
                        <option value="42">Telecel</option>
                        <option value="64">Test Bank</option>
                        <option value="24">Tetrad</option>
                        <option value="25">ZB Bank</option>
                        <option value="63">Zimbabwe Women’s Microfinance Bank Ltd</option>
                        <option value="46">Zimexpress</option>
                        <option value="29">Zimpost</option>
                        <option value="45">Zympay</option>
                    </select>
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}


            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Purpose of the Application</label>

                <div className="form-bx"><label>
                    <textarea name='purposeApplication' onChange={(e) => { changeHandelForm(e) }} placeholder="Purpose of the Application" />
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}


            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Type of Exporter</label>
                <div className="form-bx-radio mt-4">


                    {
                        applicantTypes.map((item, index) => {
                            return (
                                <>
                                    <label key={index} >
                                        <input type='radio' onChange={(e) => { changeHandelForm(e); handleUsertype(e) }} name='ApplicantType' value={item.id} checked={registerusertype == item.id} /> <span>{item.name}</span>
                                    </label>
                                </>
                            )
                        })
                    }
                    {/* {errors.niu && bankData.ApplicantType === '' ? <small className='errormsg'>{errors.ApplicantType}</small> : ""} */}

                </div>

            </div>
            {/* --end form-bx -- */}


            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Company Name</label>

                <div className="form-bx"><label>
                    <input type="text" name='companyName' value={exportForm.companyName} onChange={(e) => { changeHandelForm(e) }} placeholder="Company Name" />
                    <span className="sspan"></span>
                </label>
                    <small className="informgs">Please provide at least 3 characters for auto search of Company Name.</small>

                    <ul
                    className={
                        exportForm?.companyName != "" && filteredCompanyList.length
                        ? "filterbx"
                        : "d-none"
                    }
                  >
                    {exportForm?.companyName != ""
                      ? filteredCompanyList?.map((cur) => {
                          return (
                            <li>
                              <button
                                name="companyName"
                                onClick={(e) => {
                                    changeHandelForm(e);
                                }}
                                value={cur.companyName}
                              >
                                {cur.companyName}
                              </button>
                            </li>
                          );
                        })
                      : ""}
                  </ul>
                </div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Applicant</label>

                <div className="form-bx"><label>
                    <input type="text" name="applicant " onChange={(e) => { changeHandelForm(e) }}  placeholder="Applicant" />
                    <span className="sspan"></span>
                </label>
                </div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Applicant Reference Number</label>

                <div className='row'>
                    <div className='col-md-6'><div className="form-bx"><label>
                        <input type="text" name="applicantReferenceNumber" onChange={(e) => { changeHandelForm(e) }} placeholder="Applicant Reference Number" />
                        <span className="sspan"></span>
                    </label></div></div>

                    <div className='col-md-3'><div className="form-bx"><label>
                        <select name='applicantYear' onChange={(e) => { changeHandelForm(e) }}>
                            <option value='2024'>2024</option>
                            <option value='2023'>2023</option>
                            <option value='2022'>2022</option>
                            <option value='2021'>2021</option>
                            <option value='2020'>2020</option>
                            <option value='2019'>2019</option>
                            <option value='2018'>2018</option>
                            <option value='2017'>2017</option>
                        </select>
                        <span className="sspan"></span>
                    </label></div></div>
                    <div className='col-md-3 text-right'>
                        <button className='primrybtn'>Validate</button>
                    </div>
                </div>

            </div>
            {/* --end form-bx -- */}


            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Application Date</label>

                <div className="form-bx"><label>
                    <input type="date" name="applicationDate" onChange={(e) => { changeHandelForm(e) }} placeholder="Application Date" />
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Application Type</label>

                <div className="form-bx"><label>
                    <select name='applicationType' onChange={(e) => { changeHandelForm(e) }}>
                        <option>--Application Type--</option>
                    </select>
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Currency</label>

                <div className="form-bx"><label>
                    <select  name='currency' onChange={(e) => { changeHandelForm(e) }}>
                        <option value=''>--Select Currecny--</option>
                        {
                            currency?.map((cur, ind) => {
                                return (
                                    <option key={cur.id} value={cur.currencyCode}>{cur.currencyCode}</option>
                                )
                            })
                        }

                    </select>
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Amount</label>

                <div className="form-bx"><label>
                    <input type="text" name="amount"  onChange={(e) => { changeHandelForm(e) }} placeholder="Amount" />
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Rate</label>

                <div className="form-bx"><label>
                    <input type="text" name="rate" onChange={(e) => { changeHandelForm(e) }} placeholder="Rate" disabled />
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>USD Equivalent</label>

                <div className="form-bx"><label>
                    <input type="text" name="usdEquivalent" onChange={(e) => { changeHandelForm(e) }} placeholder="USD Equivalent" disabled />
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Related Exchange Control Reference Number</label>

                <div className="form-bx"><label>
                    <input type="text" name="relatedexchangeControlNumber" onChange={(e) => { changeHandelForm(e) }} placeholder="Related Exchange Control Reference Number" />
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}


            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Sector</label>

                <div className="form-bx"><label>
                    <select name='sector' onChange={(e) => { changeHandelForm(e) }}>
                        <option>--Sector--</option>
                    </select>
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Subsector</label>

                <div className="form-bx"><label>
                    <select name='subsector' onChange={(e) => { changeHandelForm(e) }}>
                        <option>--Subsector--</option>
                    </select>
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}


            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Applicant Comments</label>

                <div className="form-bx"><label>
                    <textarea name="applicantComments" onChange={(e) => { changeHandelForm(e) }} placeholder="Applicant Comments" />
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Submit to Bank Supervisor</label>

                <input type='checkbox' className='mt-4' />
            </div>
            {/* --end form-bx -- */}

            <div className='inner_form_new label.controlform'>
                <label className='controlform'>Select Bank Supervisor</label>

                <div className="form-bx"><label>
                    <select name='bankSupervisor' onChange={(e) => { changeHandelForm(e) }}>
                        <option>--Select--</option>
                        <option value='admin'>admin</option>
                    </select>
                    <span className="sspan"></span>
                </label></div>
            </div>
            {/* --end form-bx -- */}

            <h5 className='section_top_subheading'>Attachments</h5>

            <div className='attachemt_form-bx'>
                <label><i className="bi bi-forward"></i>
                    Applicant Letter Request</label>
                <div className='browse-btn'>Browse <input type='file'   onChange={(e) => handleFileChange(e)} /></div>
                <span className='filnename'>file.jpg</span>
            </div>

            <div className='attachemt_form-bx'>
                <label><i className="bi bi-forward"></i>
                    Agreement</label>
                <div className='browse-btn'>Browse <input type='file' onChange={(e) => handleFileChange(e)}  /></div>
                <span className='filnename'>file.jpg</span>
            </div>

           
             

            {otherfiles.map((file, index) => (
        <div key={index} className='attachemt_form-bx'>
          <label><i className="bi bi-forward"></i>  Other File {index + 1}</label>
          <div className='browse-btn'>
            Browse <input type='file' onChange={(e) => handleFileChange(e, index)} />
          </div>
          <span className='filename'>{file ? file.name : 'No file chosen'}</span>
        </div>
      ))}
            

            <button type='button' className='addmore-btn' onClick={handleAddMore}>Add More File</button>


            <div className='form-footer mt-5 mb-3'>
                <button type='reset' className='register'>Reset</button>
                <button className='login'>Submit</button>
            </div>


        </>
    )
}

export default ExportNewRequestForm

import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { APIURL } from '../constant'
import { Storage } from '../login/Storagesetting'

const ExportformDynamicField = () => {

    const RoleID = Storage.getItem('roleIDs')
    const LoginToken = Storage.getItem('loginToken')
    const UserID = Storage.getItem('userID')

    const [currency, setCurrecny]= useState([]);
    const [companies, setompanies]=useState([]);

    const [applicantTypes, setapplicantTypes] = useState([])


    const [GovernmentAgencies, setGovernmentAgencies] = useState([])

    const Getcurrecy = async()=>{

        await axios.post(APIURL + 'Master/GetCurrencyData',{
            RoleID:RoleID,
            LoginToken:LoginToken,
            UserID:UserID
        }).then((res)=>{
           
            setCurrecny(res.data.responseData)
        })
        .catch((err)=>{
            console.log(err)
        })

        await axios.post(APIURL + 'Master/GetCompanies').then((res)=>{
           
            setompanies(res.data.responseData)
        })
        .catch((err)=>{
            console.log(err)
        })

        await axios.post(APIURL + 'Master/GetGovernmentAgencies').then((res)=>{
           
            setGovernmentAgencies(res.data.responseData)
        })
        .catch((err)=>{
            console.log(err)
        }) 
        
        
        try {
            const response = await axios.post(APIURL + 'Master/GetApplicantTypes');
            if (response.data.responseCode === "200") {
                setTimeout(() => {
                    setapplicantTypes(response.data.responseData);
                }, 1000);
            } else {
                setapplicantTypes('');
            }
        } catch (error) {
            console.log(error);
        }

    }

     
    
    useEffect(()=>{
        Getcurrecy()
    },[])


    return  {
        currency,
        companies,
        GovernmentAgencies,
        applicantTypes
    }
}

export default ExportformDynamicField

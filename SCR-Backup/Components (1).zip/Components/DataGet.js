import React, { useState, useEffect } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { ToggleButton } from 'primereact/togglebutton';
// import { CustomerService } from './service/CustomerService';
import axios from 'axios';
import "../App.css"
import { FilterMatchMode, FilterService  } from 'primereact/api';
import "primereact/resources/themes/lara-light-cyan/theme.css";
import { InputNumber } from 'primereact/inputnumber';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import 'primeicons/primeicons.css';

FilterService.register('custom_activity', (value, filters) => {
    const [from, to] = filters ?? [null, null];
    if (from === null && to === null) return true;
    if (from !== null && to === null) return from <= value;
    if (from === null && to !== null) return value <= to;
    return from <= value && value <= to;
  });

 function DataGet() {
    const [customers, setCustomers] = useState([]);

    
    const [filters, setFilters] = useState({
        global: { value: null, matchMode: FilterMatchMode.CONTAINS },
        companyName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
        bankName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
        tinNumber: { value: null, matchMode: FilterMatchMode.IN },
    });
    const [loading, setLoading] = useState(false);
    const [globalFilterValue, setGlobalFilterValue] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const data = {
                    RoleID: "4",
                    UserID: "3C7212C1-53AA-40BA-9321-4C2B53C6587E"
                };
                const response = await axios.post("https://dmsupgrade.in/API/ExportApplication/GetExportApplications", data);
                if(response.status===200){
                    setCustomers(response.data.responseData);
                }
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };
    
        fetchData();
    }, []);

    const onGlobalFilterChange = (e) => {
        const value = e.target.value;
        let _filters = { ...filters };

        _filters['global'].value = value;
        setFilters(_filters);
        setGlobalFilterValue(value);
    };

    const renderHeader = () => {
        return (
            <div className="flex justify-content-end">
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue} onChange={onGlobalFilterChange} placeholder="Keyword Search" />
                </span>
            </div>
        );
    };

    const view = (refId)=> {
        console.log(refId)
    }

    const edit = (refId)=>{
        console.log(refId)
    }

    const verifiedBodyTemplate = (rowData) =>{
        return (
            <>
        <i className="pi pi-eye" style={{ padding:"12px", cursor:'pointer' }} onClick={()=>{view(rowData.rbzReferenceNumber)}}
        onMouseEnter={(e) => { e.target.style.color = 'var(--primary-color)' }}
        onMouseLeave={(e) => { e.target.style.color = '' }}
        ></i>

        <i className="pi pi-user-edit" style={{cursor:'pointer'  }} onClick={()=>{edit(rowData.rbzReferenceNumber)}}
        onMouseEnter={(e) => { e.target.style.color = 'var(--primary-color)' }}
        onMouseLeave={(e) => { e.target.style.color = '' }}
        ></i>
        </>
        );
    }

    const header=renderHeader();

    return (
        <div className="card">
          
            <DataTable value={customers} scrollable scrollHeight="400px" className="mt-4" paginator filters={filters} paginatorPosition={'both'} paginatorLeft rows={10} dataKey="id" rowsPerPageOptions={[5, 10, 25, 50]}
            globalFilterFields={['name', 'country.name', 'representative.name', 'balance']}
            emptyMessage="No customers found." header={header}
            >
                <Column field="rbzReferenceNumber" header="Ref No" sortable   style={{ minWidth: '100px' }} ></Column>
                <Column field="companyName" header="Company Name" sortable  style={{ minWidth: '200px' }}></Column>
                <Column field="bankName" header="Bank" sortable  style={{ minWidth: '200px' }}></Column>
                <Column field="applicationSubmittedDate" header="Date"  sortable  style={{ minWidth: '200px' }}></Column>
                <Column field="tinNumber" header="Number" sortable  style={{ minWidth: '200px' }}></Column>
                <Column field="amount" header="Amount" sortable  style={{ minWidth: '200px' }}></Column>
                <Column field="applicationPurpose" header="Purpose" sortable  style={{ minWidth: '200px' }}></Column>
                <Column field="" header="Action"   style={{ minWidth: '200px' }} frozen alignFrozen="right" body={verifiedBodyTemplate}> </Column>
            </DataTable>
        </div>
    );
}

export default DataGet;
        

// export const Storage = sessionStorage;

export const Storage = localStorage;
import React, { useState, useRef, useEffect } from "react";
import DataTable from "react-data-table-component";
import moment from "moment";
import axios from "axios";
import { APIURL } from "../constant";
import { Storage } from "../login/Storagesetting";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import Modal from "react-bootstrap/Modal";
import ImportDashboardViewDetails from "../components/ImportDashboardViewDetails";
// import { CSVLink } from "react-csv";
// import * as FileSaver from "file-saver";
// import * as XLSX from "xlsx";
// import ExportDashboardEditDetails from "../components/ExportDashboardEditDetails";

const ImportDashboardTable = () => {
  const useId = Storage.getItem("userID");
  const rollId = Storage.getItem("roleIDs");

  const [importData, setImportData] = useState([]);

  // application form start
  const [showEditForm, setshowEditForm] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [applicationDetail, setApplicationDetail] = useState({});
  const [applicationmessage, setApplicationmessage] = useState("");
  const [editData, setEditdata] = useState({});
  const [searchText, setSearchText] = useState("");

  const EditModalClose = () => setshowEditForm(false);
  const handleFormClose = () => setShowUpdateModal(false);

  const csvLinkRef = useRef();

  const handleClickEditModal = (title) => {
    setshowEditForm(true);
  };

  useEffect(() => {
    const handleData = async () => {
      await axios
        .post(APIURL + "ImportApplication/GetImportApplications", {
          UserID: useId.replace(/"/g, ""),
          RoleID: rollId,
        })
        .then((res) => {
          if (res.data.responseCode === "200") {
            setImportData(res.data.responseData);
          }
        });
    };
    handleData();
  }, []);

  const columns = [
    // {
    //     name: 'Image',
    //     selector: row => row.img,
    //     cell: (d) => [
    //         <img src={d.img} className="imgicon" />
    //     ]
    // },
    {
      name: "RBZ Reference Number",
      selector: (row) => row.rbzReferenceNumber,
      sortable: true,
      searchable: true,
      width: "280px",
    },
    {
      name: "Applicant Name",
      selector: (row) => row.name,
      sortable: true,
      searchable: true,
      width: "200px",
    },
    {
      name: "Submitted Date",
      selector: (row) =>
        moment(row.applicationSubmittedDate).format("DD-MM-YYYY"),
      sortable: true,
      width: "160px",
    },
    {
      name: "Received By RBZ date",
      selector: (row) =>
        moment(row.applicationSubmittedDate).format("DD-MM-YYYY"),
      sortable: true,
      searchable: true,
      width:"210px"
    },
    {
      name: "Application Type",
      selector: (row) => row.applicationType,
      sortable: true,
      width: "190px",
    },
    {
      name: "Currency",
      selector: (row) => row.currencyName,
      sortable: true,
    },
    {
      name: "Amount",
      selector: (row) => row.amount,
      sortable: true,
    },
    {
      name: "Status",
      selector: (row) =>row.status == 0 ? "Draft" :  "Submitted to bank Analyst",
      sortable: true,
      width:"190px"
    },
    {
      name: "Response Date",
      selector: (row) =>
        row.responseDate ? moment(row.responseDate).format("DD:MM:YYYY") : "--",
      sortable: true,
      searchText: true,
      width:"160px"
    },
    {
      name: "Action",
      // selector: row => row.Details,
      cell: (row) => [
        <Link
          onClick={() => {
            handleViewData(row.id);
            GetHandelDetail(row?.id);
            // alert("work in progress");
          }}
          className="mr-1"
        >
          <b>
            <i className="bi bi-eye"></i>
          </b>
        </Link>,
        <button
          key={row.title}
          onClick={() => {
            toast("Work in progress");
            // handleClickEditModal(row.title);
            // HandleEditeForm(row?.rbzReferenceNumber);
          }}
          className="edit-btn"
        >
          <i className="bi bi-pencil"></i>
        </button>,
        <button
          onClick={() => {
            toast("Work in progress");
            // handleClickEditModal(row.title)
          }}
          className="delete-btn"
        >
          <i className="bi bi-trash"></i>
        </button>,
      ],
    },

    // {
    //   name: "Edit Details",
    //   sortable: false,
    //   selector: "null",
    //   cell: (row) => [
    //     <button
    //       key={row.title}
    //       onClick={() => handleClickEditModal(row.title)}
    //       className="edit-btn"
    //     >
    //       <i className="bi bi-pencil"></i>
    //     </button>,
    //   ],
    // },
    // {
    //   name: "Delete",
    //   sortable: false,
    //   selector: "null",
    //   cell: (row) => [
    //     <button
    //       onClick={() => handleClickEditModal(row.title)}
    //       className="delete-btn"
    //     >
    //       <i className="bi bi-trash"></i>
    //     </button>,
    //   ],
    // },
  ];

  const handleViewData = (id) => {
    setShowUpdateModal(true);
  };

  const GetHandelDetail = async (id) => {
    await axios
      .post(APIURL + "ImportApplication/GetImportRequestInfoByApplicationID", {
        ID: `${id}`,
      })
      .then((res) => {
        if (res.data.responseCode === "200") {
          setApplicationDetail(res.data.responseData);
        } else {
          setApplicationmessage(res.data.responseMessage);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const HandleEditeForm = (rbzrefnumber) => {
    axios
      .post(APIURL + "ExportApplication/GetRequestInfoByApplicationID", {
        RBZReferenceNumber: `${rbzrefnumber}`,
      })
      .then((res) => {
        if (res.data.responseCode === "200") {
          setEditdata(res.data.responseData);
        } else {
          toast(res.data.responseMessage);
        }
      });
  };

  const filteredData = importData?.filter(
    (item) =>
      item?.rbzReferenceNumber
        ?.toLowerCase()
        .includes(searchText?.toLowerCase()) ||
      item?.name?.toLowerCase().toString().includes(searchText) ||
      item?.supervisorName?.toLowerCase().toString().includes(searchText) ||
      item?.amount?.toString().includes(searchText) ||
      item?.name?.toLowerCase().toString().includes(searchText) ||
      moment(item?.applicationSubmittedDate)
        .format("DD:MM:YYYY")
        ?.toString()
        .includes(searchText) ||
      item?.applicationType?.toLowerCase().toString().includes(searchText) ||
      item?.currencyName?.toLowerCase().toString().includes(searchText)
  );

  // const handleExportExcel = () => {
  //     const worksheet = XLSX.utils.json_to_sheet(filteredData);
  //     const workbook = XLSX.utils.book_new();
  //     XLSX.utils.book_append_sheet(workbook, worksheet, "Movie Data");
  //     const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  //     const excelData = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  //     FileSaver.saveAs(excelData, "movie_data.xlsx");
  // };

  return (
    <>
      {importData.length === 0 ? (
        <div className="p-3">No records to show</div>
      ) : (
        <>
          <DataTable
            columns={columns}
            data={filteredData}
            pagination
            highlightOnHover
            className="exporttable"
            dense
            subHeader
            subHeaderComponent={
              <div className="tablesearch">
                <div className="tablesearch_bx">
                  <input
                    type="text"
                    placeholder="Search..."
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                  />
                </div>
              </div>
            }
          />

          <Modal
            show={showUpdateModal}
            onHide={handleFormClose}
            backdrop="static"
            className="max-width-600"
          >
            <div className="application-box">
              <div className="login_inner">
                <div class="login_form ">
                  <h5>
                    <Modal.Header closeButton className="p-0">
                      <Modal.Title>View Import Request</Modal.Title>
                    </Modal.Header>
                  </h5>
                </div>
                <div className="login_form_panel">
                  <Modal.Body className="p-0">
                    <ImportDashboardViewDetails
                      applicationDetail={applicationDetail}
                      applicationmessage={applicationmessage}
                      handleFormClose={handleFormClose}
                    />
                  </Modal.Body>
                </div>
              </div>
            </div>
          </Modal>

          {/* <Modal
            show={showEditForm}
            onHide={EditModalClose}
            backdrop="static"
            className="max-width-600"
          >
            <div className="application-box">
              <div className="login_inner">
                <div class="login_form ">
                  <h5>
                    <Modal.Header closeButton className="p-0">
                      <Modal.Title>Edit Export Request</Modal.Title>
                    </Modal.Header>
                  </h5>
                </div>
                <div className="login_form_panel">
                  <Modal.Body className="p-0">
                     <ExportDashboardEditDetails editData={editData} />
                  </Modal.Body>
                </div>
              </div>
            </div>
          </Modal> */}
        </>
      )}
    </>
  );
};

export default ImportDashboardTable;

import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import ExportformDynamicField from "./ExportformDynamicField";
import { Storage } from "../login/Storagesetting";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import axios from "axios";
import { APIURL } from "../constant";
import moment from "moment";
import { toast } from "react-toastify";

const ExportDashboardEditDetails = ({applicationDetail, setApplicationDetail, EditModalClose, handleData}) => { 

  const {
    currency,
    companies,
    GovernmentAgencies,
    applicantTypes,
    sectorData,
    masterBank,
    Supervisors,
    applicantName,
  } = ExportformDynamicField();

  const BPNCodeRef = useRef(null);
  const TINRef = useRef(null);
  const amountRef = useRef(null);
  const applicantRef = useRef(null);
  const BeneficiaryNameRef = useRef(null);
  const applicantCommentsRef = useRef(null);
  const applicantReferenceNumberRef = useRef(null);
  // const applicantYearRef = useRef(null);
  const applicationTypeRef = useRef(null);
  const assignedToRef = useRef(null);
  const companyNameRef = useRef(null);
  const currencyRef = useRef(null);
  const govtAgencieRef = useRef(null);
  const applicationPurposeRef = useRef(null);

  const relatedexchangeControlNumberRef = useRef(null);
  const sectorRef = useRef(null);
  const subsectorRef = useRef(null);
  const typeExporterRef = useRef(null);
  const rateRef = useRef(null);
  const usdEquivalentRef = useRef(null);

  const UserID = Storage.getItem("userID");
  const bankID = Storage.getItem("bankID");
  const userName = Storage.getItem("userName");
  const bankName = Storage.getItem("bankName");
  const bankidcheck = bankID !== "" ? "1" : "3";

  const [startDate, setStartDate] = useState(new Date());
  const [toastDisplayed, setToastDisplayed] = useState(false);
  const [getCompanyName, setgetCompanyName] = useState();
  const [getCompanyId, setgetCompanyId] = useState("");
  const [checksectorchange, setchecksectorchange]=useState(false);

  let dateApp = moment(startDate).format("DD-MM-YYYY");

  const [registerusertype, setregisterusertype] = useState(applicationDetail?.userTypeID);
  
  const [files, setFiles] = useState([]);

  const [otherfiles, setOtherfiles] = useState([]);
  const [errors, setErrors] = useState({});
  const [applicationType, setapplicationType] = useState([]);
  const [subsectorData, setsubsectorData] = useState([]);
  const [curRate, setCurrate] = useState(1);
  const [checkSupervisor, setcheckSupervisor] = useState(applicationDetail?.supervisorName ? true : false);
  const [attachmentData, setAttachmentData] = useState([]);
  const [otherfilesupload, setOtherfilesupload] = useState([]);
  const [value, setValue] = useState("Company Name");
  // const [finlterapplicantName, setFinlterapplicantName] = useState([]); 

 

  const changeHandelForm = (e) => {
    const name = e.target.name;
    const value = e.target.value;    
    const specialChars = /[!@#$%^&*(),.?":{}|<>]/;
    let newErrors = {};
    let valid = true
 
    console.log("name---edit", name)

    if (name == "applicationPurpose" && value.charAt(0) === ' ') { 
      newErrors.applicationPurpose = "First character cannot be a blank space"; 
      valid = false
  } 
  else if (name == "applicationPurpose" && specialChars.test(value)) { 
    newErrors.applicationPurpose = "Special characters not allowed"; 
    valid = false
} 

else if (name == "applicant" && value.charAt(0) === ' ') { 
  newErrors.applicant = "First character cannot be a blank space"; 
  valid = false
} 
else if (name == "applicant" && specialChars.test(value)) { 
newErrors.applicant = "Special characters not allowed"; 
valid = false
} 

else if (name == "applicantComment" && value.charAt(0) === ' ') { 
  newErrors.applicantComment = "First character cannot be a blank space"; 
  valid = false
}  
else if (name == "beneficiaryName" && value.charAt(0) === ' ') { 
  newErrors.beneficiaryName = "First character cannot be a blank space"; 
  valid = false
}  
else if (name == "beneficiaryName" && specialChars.test(value)) { 
  newErrors.beneficiaryName = "Special characters not allowed"; 
  valid = false
  } 
else if (name == "tinNumber" && value.charAt(0) === ' ') { 
  newErrors.tinNumber = "First character cannot be a blank space"; 
  valid = false
}  
else if (name == "tinNumber" && specialChars.test(value)) { 
  newErrors.tinNumber = "Special characters not allowed"; 
  valid = false
  }
  else if (name == "bpnCode" && value.charAt(0) === ' ') { 
    newErrors.bpnCode = "First character cannot be a blank space"; 
    valid = false
  }  
  else if (name == "bpnCode" && specialChars.test(value)) { 
    newErrors.bpnCode = "Special characters not allowed"; 
    valid = false
    } 
    else if (name == "applicantReferenceNumber" && value.charAt(0) === ' ') { 
      newErrors.applicantReferenceNumber = "First character cannot be a blank space"; 
      valid = false
    }  
    else if (name == "applicantReferenceNumber" && specialChars.test(value)) { 
      newErrors.applicantReferenceNumber = "Special characters not allowed"; 
      valid = false
      }  
      else if (name == "relatedexchangeControlNumber" && value.charAt(0) === ' ') { 
        newErrors.relatedexchangeControlNumber = "First character cannot be a blank space"; 
        valid = false
      }  
      else if (name == "relatedexchangeControlNumber" && specialChars.test(value)) { 
        newErrors.relatedexchangeControlNumber = "Special characters not allowed"; 
        valid = false
        } 
 
    

else{
  setErrors({});
    setApplicationDetail((prevState) => ({
      ...prevState,
      [name]: value,
    })); 
  }

  setErrors(newErrors);

    if (name === "sector") {
      axios
        .post(APIURL + "Master/GetSubSectorBySectorID", {
          SectorID: value,
        })
        .then((res) => {
          if (res.data.responseCode == "200") {
            setchecksectorchange(true)
            setsubsectorData(res.data.responseData);
          } else {
            setsubsectorData([]);
            console.log(res.data.responseMessage);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
    if(name == "subSector"){
      setchecksectorchange(false)
    }

    if (name === "currency" && value != "") {
      axios
        .post(APIURL + "Master/GetRateByCurrencyID", {
          Id: value,
        })
        .then((res) => {
          console.log("rateeeeeee" ,res)
          if (res.data.responseCode == "200") {
            setCurrate(res.data.responseData.currencyRate);
          } else {
            setCurrate([]);
            console.log(res.data.responseMessage);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
    if (name === "applicationTypeID") {
      axios
        .post(APIURL + "Master/GetAttachmentData", {
          ApplicationTypeID: value != "" ? value : -1,
          ApplicationSubTypeID: "0",
        })
        .then((res) => {
          if (res.data.responseCode == "200") {
            setAttachmentData(res.data.responseData);
          } else {
            setAttachmentData([]);
            setFiles([]);
            setOtherfiles([]);
            setOtherfilesupload([]);
          }
        });
    }
  }; 

  const convertedRate = parseFloat(curRate) * parseFloat(applicationDetail?.amount);
 

  const GetApplicationTypes = async () => {
    await axios
      .post(APIURL + "Master/GetApplicationTypesByDepartmentID", {
        DepartmentID: "1",
      })
      .then((res) => {
        if (res.data.responseCode === "200") {
          setapplicationType(res.data.responseData);
        } else {
          console.log(res.data.responseMessage);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    GetApplicationTypes();
    if (applicationDetail?.subSector) { 
      axios
        .post(APIURL + "Master/GetSubSectorBySectorID", {
          SectorID: parseInt(applicationDetail.sector),
        })
        .then((res) => {
          if (res.data.responseCode == "200") {
            setsubsectorData(res.data.responseData);
          } else {
            setsubsectorData([]);
            console.log(res.data.responseMessage);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
    
  }, [applicationDetail.sector]);
  const handleUsertype = (e) => {
    setregisterusertype(e.target.value);
  };

  const handleAddMore = (e) => {
    setOtherfiles([...otherfiles, null]);
  };

  const handleFileChange = (e, id) => {
    // const file = e.target.files[0];
    // setFiles([...files, file, id]);

    const file = e.target.files[0];
    setFiles((prevFiles) => [...prevFiles, { file, id }]);
  };

  const handleOthrefile = (e, id) => {
    const otherfile = e.target.files[0];
    setOtherfilesupload([...otherfilesupload, { otherfile, id }]);
  };

  const HandelSupervisorcheck = (e) => {
    setcheckSupervisor(!checkSupervisor);
  };


 
  const validateForm = () => {
    let valid = true;
    const newErrors = {};

    const numericRegex = /\d/;

    if (applicationDetail.applicationPurpose === "") {
      newErrors.applicationPurpose = "Purpose of the application is required";
      valid = false;
    }
    // if (
    //   registerusertype === "1" &&
    //   (getCompanyName === "" ||
    //     getCompanyName === "Company Name" ||
    //     getCompanyName == null)
    // ) {
    //   newErrors.companyName = "Corporate name is required";
    //   valid = false;
    // }
    if (applicationDetail.applicationTypeID === "") {
      newErrors.applicationTypeID = "Application type is required";
      valid = false;
    }
    if (
      bankID == "" &&
      registerusertype === "3" &&
      applicationDetail.govtAgencie === ""
    ) {
      newErrors.govtAgencie = "Government agencies name is required";
      valid = false;
    }
    // if (registerusertype === "1" && applicationDetail.BPNCode === "") {
    //   newErrors.BPNCode = "BPN code is required";
    //   valid = false;
    // }
    // if (registerusertype === "2" && applicationDetail.TIN === "") {
    //   newErrors.TIN = "TIN is Required";
    //   valid = false;
    // }
    if (registerusertype === "2" && applicationDetail.applicant === "") {
      newErrors.applicant = "Applicant name is required";
      valid = false;
    }
    // if (applicationDetail.applicantReferenceNumber === "") {
    //   newErrors.applicantReferenceNumber =
    //     "Applicant reference number is required";
    //   valid = false;
    // }

    if (applicationDetail.currency === "") {
      newErrors.currency = "Currency is required";
      valid = false;
    }
    if (applicationDetail.amount === "") {
      newErrors.amount = "Amount is required";
      valid = false;
    }
    // if (applicationDetail.relatedexchangeControlNumber === "") {
    //   newErrors.relatedexchangeControlNumber =
    //     "Related exchange control reference number is required";
    //   valid = false;
    // }
    if (applicationDetail.sector === "") {
      newErrors.sector = "Sector is required";
      valid = false;
    }
    if (applicationDetail.subSector === "" || checksectorchange === true) {
      newErrors.subSector = "Sub sector is required";
      valid = false;
    }
    if (applicationDetail.applicantComment === "") {
      newErrors.applicantComment = "Applicant comments is required";
      valid = false;
    }
    if (checkSupervisor == true && applicationDetail.assignedTo === "" || applicationDetail.assignedTo == null) {
      newErrors.assignedTo = "Bank supervisor is required";
      valid = false;
    }
    // if(files.length < attachmentData.length){
    //   newErrors.files = "All Files Required";
    //   valid = false;
    // }

    setErrors(newErrors);
    return valid;
  };

  console.log("errors", errors)
  console.log("checksectorchange", checksectorchange)
console.log("getCompanyName", getCompanyName)

  const SearchableDropdown = ({
    options,
    label,
    id,
    selectedVal,
    handleChange,
  }) => {
    // console.log("options, label, selectedVal, handleChange", options, label, selectedVal, handleChange)
     
    const [query, setQuery] = useState("");
    const [isOpen, setIsOpen] = useState(false);

    const inputRef = useRef(null);
    useEffect(() => {
      document.addEventListener("click", toggle);
      return () => document.removeEventListener("click", toggle); 
     
    }, []);

    

    const selectOption = (option) => {
      setQuery(() => "");
      handleChange(option[label]);
      setIsOpen((isOpen) => !isOpen);
      setgetCompanyId(option.id);
    };

    function toggle(e) {
      setIsOpen(e && e.target === inputRef.current);
    }

    const getDisplayValue = () => {
      if (query) return query;
      if (selectedVal) return selectedVal;
      return "";
    };

    setgetCompanyName(selectedVal);

    const filter = (options) => {
      if (Array.isArray(options) && options.length > 0 && query.length >= 3) {
        return options.filter(
          (option) =>
            option[label]?.toLowerCase().indexOf(query.toLowerCase()) > -1
        );
      } else {
        return [];
      }
    };

    return (
      <> 
      
      <div className="dropdownExpComName">
        <div className="control">
          <div className="selected-value">
            <input
              className="borderdisplaynone"
              ref={inputRef}
              type="text"
              // value={getDisplayValue()}
              name="bankName"
              onChange={(e) => {
                setQuery(e.target.value);
                handleChange(null);
                changeHandelForm(e)
              }}
              onClick={toggle}
            />
          </div>
          {/* <div className={`arrow ${isOpen ? "open" : ""}`}></div> */}
        </div>

        <div className={`options ${isOpen ? "open" : ""}`}>
          {filter(options).map((option, index) => {
            return (
              <div
                onClick={() => selectOption(option)}
                className={`option ${
                  option[label] === selectedVal ? "selected" : ""
                }`}
                key={`${id}-${index}`}
              >
                {option[label]}
              </div>
            );
          })}
        </div>
      </div>
      </>
    );
  }; 

  const HandleSubmit = async (e) => {
    e.preventDefault();  

    if (validateForm()) {
      await axios
        .post(APIURL + "ExportApplication/UpdateExportApplications", {
          RBZReferenceNumber: applicationDetail?.rbzReferenceNumber,
          DepartmentID: "1",
          AssignedTo: applicationDetail?.assignedTo,
          BankID: applicationDetail?.bankID,
          CompanyID: applicationDetail.userTypeID == "1" && applicationDetail?.bankID !=="" ? applicationDetail?.companyID : "",
          ApplicationPurpose: applicationDetail?.applicationPurpose,
          UserTypeID: applicationDetail?.userTypeID,
          Name: applicationDetail?.userTypeID == "1" && applicationDetail?.bankID !==""
          ? applicationDetail?.companyName
          : applicationDetail?.userTypeID == "2" && applicationDetail?.bankID !== ""
          ? applicationDetail?.name : "", 
          BeneficiaryName: applicationDetail?.beneficiaryName,
          BPNCode: applicationDetail?.bpnCode?.toUpperCase(),
          TINNumber: applicationDetail?.tinNumber?.toUpperCase(),
          ApplicantReferenceNumber: applicationDetail?.applicantReferenceNumber,
          ApplicationTypeID: applicationDetail?.applicationTypeID,
          Currency: applicationDetail?.currency,
          Amount: applicationDetail?.amount,
          Rate:applicationDetail?.rate,
          USDEquivalent: applicationDetail?.usdEquivalent,
          RECNumber: applicationDetail?.relatedexchangeControlNumber?.toUpperCase(),
          Sector: applicationDetail?.sector,
          SubSector: applicationDetail?.subSector,
          ApplicantComment: applicationDetail?.applicantComment,
          ApplicationDate: applicationDetail?.applicationDate ? applicationDetail?.applicationDate : startDate
        })
        .then((res) => {
          if (res.data.responseCode === "200") {
            toast.success(res.data.responseMessage);
            EditModalClose()
            handleData()
          } else {
            toast.error(res.data.responseMessage);
          }
        })
        .catch((err) => {
          console.log(err);
        });

      setApplicationDetail({
        user: "",
        bankName: bankName,
        applicationPurpose: "",
        typeExporter: "",
        // companyName: "",
        BeneficiaryName: "",
        govtAgencie: "",
        BPNCode: "",
        TINNumber: "",
        applicant: "",
        applicantReferenceNumber: "",
        applicantYear: "2024",
        // applicationDate:dateApp ,
        exporterType: "",
        currency: "",
        amount: "",
        rate: "",
        usdEquivalent: "",
        relatedexchangeControlNumber: "",
        sector: "",
        subsector: "",
        applicantComments: "",
        assignedTo: "",
      });
      if (BPNCodeRef.current) BPNCodeRef.current.value = "";
      if (TINRef.current) TINRef.current.value = "";
      if (amountRef.current) amountRef.current.value = "";
      if (applicantRef.current) applicantRef.current.value = "";
      if (applicantCommentsRef.current) applicantCommentsRef.current.value = "";
      if (BeneficiaryNameRef.current) BeneficiaryNameRef.current.value = "";
      if (applicantReferenceNumberRef.current)
        applicantReferenceNumberRef.current.value = "";
      // if(applicantYearRef.current) applicantYearRef.current.value = '';
      if (applicationTypeRef.current) applicationTypeRef.current.value = "";
      if (assignedToRef.current) assignedToRef.current.value = "";
      if (companyNameRef.current) companyNameRef.current.value = "";
      if (currencyRef.current) currencyRef.current.value = "";
      if (govtAgencieRef.current) govtAgencieRef.current.value = "";

      if (applicationPurposeRef.current)
        applicationPurposeRef.current.value = "";
      if (relatedexchangeControlNumberRef.current)
        relatedexchangeControlNumberRef.current.value = "";
      if (sectorRef.current) sectorRef.current.value = "";
      if (subsectorRef.current) subsectorRef.current.value = "";

      if (typeExporterRef.current) typeExporterRef.current.value = "";
      if (usdEquivalentRef.current) usdEquivalentRef.current.value = "";

      if (rateRef.current) rateRef.current.value = "";
    } else {
      if (!toastDisplayed) {
        toast.warning("Please fill all fields");
      }
      setToastDisplayed(true);
    }
  };

  console.log("applicationDetail", applicationDetail)
  const ResetHandleData = () => {
    setgetCompanyName("");
    setApplicationDetail({
      user: "",
      bankName: bankName,
      applicationPurpose: "",
      typeExporter: "",
      // companyName: "",
      govtAgencie: "",
      BPNCode: "",
      TIN: "",
      applicant: "",
      applicantReferenceNumber: "",
      // applicantYear: "2024",
      // applicationDate:dateApp ,
      exporterType: "",
      currency: "",
      amount: "",
      rate: "",
      usdEquivalent: "",
      relatedexchangeControlNumber: "",
      sector: "",
      subsector: "",
      applicantComments: "",
      assignedTo: "",
    });
    if (BPNCodeRef.current) BPNCodeRef.current.value = "";
    if (TINRef.current) TINRef.current.value = "";
    if (amountRef.current) amountRef.current.value = "";
    if (applicantRef.current) applicantRef.current.value = "";
    if (applicantCommentsRef.current) applicantCommentsRef.current.value = "";
    if (applicantReferenceNumberRef.current)
      applicantReferenceNumberRef.current.value = "";
    // if(applicantYearRef.current) applicantYearRef.current.value = '';
    if (applicationTypeRef.current) applicationTypeRef.current.value = "";
    if (assignedToRef.current) assignedToRef.current.value = "";
    if (companyNameRef.current) companyNameRef.current.value = "";
    if (currencyRef.current) currencyRef.current.value = "";
    if (govtAgencieRef.current) govtAgencieRef.current.value = "";

    if (applicationPurposeRef.current) applicationPurposeRef.current.value = "";
    if (relatedexchangeControlNumberRef.current)
      relatedexchangeControlNumberRef.current.value = "";
    if (sectorRef.current) sectorRef.current.value = "";
    if (subsectorRef.current) subsectorRef.current.value = "";

    if (typeExporterRef.current) typeExporterRef.current.value = "";
    if (usdEquivalentRef.current) usdEquivalentRef.current.value = "";

    if (rateRef.current) rateRef.current.value = "";

    setOtherfilesupload([]);
    setFiles([]);
    setErrors({});
    setregisterusertype(bankidcheck);
  };

  useEffect(() => {
    if (toastDisplayed) {
      setTimeout(() => {
        setToastDisplayed(false);
      }, 1500);
    }
    
  }, [toastDisplayed]);

  useEffect(()=>{
    if(applicationDetail?.assignedTo !=""){ 
      setcheckSupervisor(true) 
    }else{ 
      setcheckSupervisor(false)
    } 
  },[])

  console.log("applicationDetail", applicationDetail)

  return (
    <>
      <h3 className="export-pop-heading">
        {applicationDetail?.rbzReferenceNumber ? applicationDetail.rbzReferenceNumber : ""}
      </h3>
      <h5 class="section_top_subheading">General Info</h5>
      
    <form>
      <div className="inner_form_new ">
        <label className="controlform">User</label>

        <div className="form-bx">
          <label>
            <input
              type="text"
              name="user"
              value={applicationDetail.userName?.replace(/"/g, "")}
              onChange={(e) => {
                changeHandelForm(e);
              }}
              disabled
            />
            <span className="sspan"></span>
          </label>
        </div>
      </div>
      {/* end form-bx  */}

      {bankName != "null" && (
        <div className="inner_form_new ">
          <label className="controlform">Name of Bank</label>

          <div className="form-bx">
            <label>
              <input
                type="text"
                value={bankName.replace(/"/g, "")}
                disabled
              />
              <span className="sspan"></span>
            </label>
          </div>
        </div>
      )}
      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">Purpose of the Application</label>

        <div className="form-bx">
          <label>
            <textarea
              name="applicationPurpose"
              ref={applicationPurposeRef}
              onChange={(e) => {
                changeHandelForm(e);
              }}
              placeholder="Purpose of the Application"
              className={
                errors.applicationPurpose 
                  ? "error"
                  : ""
              }
              value={applicationDetail.applicationPurpose}
            />
            <span className="sspan"></span>
            {errors.applicationPurpose  ? (
              <small className="errormsg">{errors.applicationPurpose}</small>
            ) : (
              ""
            )}
          </label>
        </div>
      </div>
      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">Type of Exporter</label>
        <div className="form-bx-radio mt-4">
          {applicantTypes.map((item, index) => {
            return (
              <>
                <label key={index}>
                  <input
                    type="radio"
                    ref={typeExporterRef}
                    onChange={(e) => {
                      changeHandelForm(e);
                      handleUsertype(e);
                    }}
                    name="userTypeID"
                    value={item.id}
                    checked={applicationDetail.userTypeID == item.id}
                    disabled={applicationDetail?.userTypeID == item.id ? false : true}
                    // disabled={
                    //   applicationDetail?.bankID != "" && item.id === 3
                    //     ? true
                    //     : bankidcheck == "3"
                    //     ? true
                    //     : false
                    // }
                  />{" "}
                  <span>{item.name}</span>
                </label>
              </>
            );
          })}
          {/* {errors.niu && bankData.ApplicantType === '' ? <small className='errormsg'>{errors.ApplicantType}</small> : ""} */}
        </div>
      </div>
      {/* end form-bx  */}

      {/* {registerusertype === "1" && bankID != "" ? (
        <div className="inner_form_new ">
          <label className="controlform">Corporate Name</label>
          <div className="form-bx">
            <label>
              <input
                type="text"
                ref={companyNameRef}
                name="companyName"
                value={applicationDetail.companyName}
                onChange={(e) => {
                  changeHandelForm(e);
                }}
                placeholder="Corporate Name"
                className={
                  errors.companyName && applicationDetail.companyName === ""
                    ? "error"
                    : ""
                }
              />
              <span className="sspan"></span>
            </label>
            {errors.companyName && applicationDetail.companyName === "" ? (
              <small className="errormsg">{errors.companyName}</small>
            ) : (
              ""
            )}
            <small className="informgs">
              Please provide at least 3 characters for auto search of Company
              Name.
            </small>
            <ul
              className={
                applicationDetail?.companyName != "" && filteredCompanyList.length
                  ? "filterbx"
                  : "d-none"
              }
            >
              {applicationDetail?.companyName != ""
                ? filteredCompanyList?.map((cur) => {
                    return (
                      <li>
                        <button
                          name="companyName"
                          onClick={(e) => {
                            changeHandelForm(e);
                          }}
                          value={cur.companyName}
                        >
                          {cur.companyName}
                        </button>
                      </li>
                    );
                  })
                : ""}
            </ul>
          </div>
        </div>
      ) : (
        ""
      )} */}

      {applicationDetail?.userTypeID == "1" && bankID != "" ? (
        <>
          <div className="inner_form_new ">
            <label className="controlform">Company Name</label>
            <div className="form-bx">
              <SearchableDropdown
                options={companies}
                label="companyName"
                id={companies[value]}
                selectedVal={applicationDetail?.companyName ? applicationDetail?.companyName : value}
                handleChange={(val) => {
                  setValue(val);
                }}
              />
              {errors.companyName &&
              (getCompanyName === "Company Name" ||
                getCompanyName == null) ? (
                <small className="errormsg">{errors.companyName}</small>
              ) : (
                ""
              )}

              <small className="informgs">
                Please provide at least 3 characters for auto search of
                Company Name.
              </small>
            </div>
          </div>

          <div className="inner_form_new ">
            <label className="controlform">TIN Number</label>
            <div className="form-bx">
              <label>
                <input
                  type="text"
                  name="tinNumber"
                  onChange={(e) => {
                    changeHandelForm(e);
                  }}
                  placeholder="TIN Number"
                  value={applicationDetail.tinNumber}
                  className="text-uppercase"
                />
                <span className="sspan"></span>
              </label>
            </div>
          </div>
        </>
      ) : (
        ""
      )}

      {/* end form-bx  */}

      {applicationDetail?.userTypeID == "2" && bankID != "" ? (
        <>
          <div className="inner_form_new ">
            <label className="controlform">Applicant</label>
            <div className="form-bx">
              <label>
                <input
                  type="text"
                  ref={applicantRef}
                  name="name"
                  onChange={(e) => {
                    changeHandelForm(e);
                  }}
                  placeholder="Applicant"
                  value={applicationDetail?.name}
                  className={
                    errors.applicant && applicationDetail?.name === ""
                      ? "error"
                      : ""
                  }
                />
                <span className="sspan"></span>
                {errors.applicant && applicationDetail.name === "" ? (
                  <small className="errormsg">{errors.applicant}</small>
                ) : (
                  ""
                )}
              </label>
              {/* <small className="informgs">
              Please provide at least 3 characters for auto search of
              Applicant Name.
            </small> */}

              {/* <ul
              className={
                applicationDetail?.applicant != "" && finlterapplicantName.length
                  ? "filterbx"
                  : "d-none"
              }
            >
              {applicationDetail?.applicant != ""
                ? finlterapplicantName?.map((cur) => {
                    return (
                      <li>
                        <button
                          type="button"
                          name="applicant"
                          onClick={(e) => {
                            changeHandelForm(e); setFinlterapplicantName([])
                          }}
                          value={cur.name}
                        >
                          {cur.name}
                        </button>
                      </li>
                    );
                  })
                : ""}
            </ul> */}
            </div>
          </div>

          <div className="inner_form_new ">
            <label className="controlform">Beneficiary Name</label>
            <div className="form-bx">
              <label>
                <input
                  type="text"
                  ref={BeneficiaryNameRef}
                  name="beneficiaryName"
                  onChange={(e) => {
                    changeHandelForm(e);
                  }}
                  placeholder="Beneficiary Name"
                  value={applicationDetail?.beneficiaryName}
                />
                <span className="sspan"></span>
              </label>
            </div>
          </div>
        </>
      ) : (
        ""
      )}

      {/* end form-bx  */}

      {applicationDetail?.userTypeID == "1" && bankID != "" ? (
        <div className="inner_form_new ">
          <label className="controlform">BPN Code</label>

          <div className="form-bx">
            <label>
              <input
                ref={BPNCodeRef}
                type="text"
                min={0}
                name="bpnCode" 
                value={applicationDetail?.bpnCode.trim()}
                onChange={(e) => {
                  changeHandelForm(e);
                }}
                placeholder="BPN Code"
                className={
                  errors.bpnCode ? "error text-uppercase" : "text-uppercase"
                }
              />
              <span className="sspan"></span>
              {errors.bpnCode ? (
                <small className="errormsg">{errors.bpnCode}</small>
              ) : (
                ""
              )}
            </label>
          </div>
        </div>
      ) : (
        ""
      )}

      {/* end form-bx  */}

      {/* {registerusertype === "2" && bankID != "" ? (
      <div className="inner_form_new ">
        <label className="controlform">TIN Number</label>

        <div className="form-bx">
          <label>
            <input
            ref={TINRef}
              type="number"
              min={0}
              name="TIN"
              onChange={(e) => {
                changeHandelForm(e);
              }}
              placeholder="TIN Number"
              className={errors.TIN && applicationDetail.TIN ==='' ? "error" : ""}
            />
            <span className="sspan"></span>
            {errors.TIN && applicationDetail.TIN ==='' ? <small className="errormsg">{errors.TIN}</small> :""}
          </label>
        </div>
      </div>
    ) : (
      ""
    )} */}

      {/* end form-bx  */}

      {bankID == "" ? (
        <div className="inner_form_new ">
          <label className="controlform">Government Agencies</label>

          <div className="form-bx">
            <label>
              <select
                ref={govtAgencieRef}
                name="govtAgencie"
                onChange={(e) => {
                  changeHandelForm(e);
                }}
                className={
                  errors.govtAgencie && applicationDetail?.govtAgencie === ""
                    ? "error"
                    : ""
                }
              >
                <option value="">Select Government Agencies Name</option>
                {GovernmentAgencies?.map((item, index) => {
                  return (
                    <option value={item.id} key={index}>
                      {item.agencyName}
                    </option>
                  );
                })}
              </select>
              <span className="sspan"></span>
              {errors.govtAgencie && applicationDetail?.govtAgencie === "" ? (
                <small className="errormsg">{errors.govtAgencie}</small>
              ) : (
                ""
              )}
            </label>
          </div>
        </div>
      ) : (
        ""
      )}

      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">Applicant Reference Number</label>

        <div className="row">
          <div className="col-md-12">
            <div className="d-flex">
              <div className="form-bx">
                <label>
                  <input
                    ref={applicantReferenceNumberRef}
                    type="text"
                    name="applicantReferenceNumber"
                    onChange={(e) => {
                      changeHandelForm(e);
                    }}
                    placeholder="Applicant Reference Number"
                    className={
                      errors.applicantReferenceNumber  
                        ? "error text-uppercase"
                        : "text-uppercase"
                    }
                    value={applicationDetail?.applicantReferenceNumber}
                  />
                  <span className="sspan"></span>
                  {errors.applicantReferenceNumber  ? (
                    <small className="errormsg">
                      {errors.applicantReferenceNumber}
                    </small>
                  ) : (
                    ""
                  )}
                </label>
              </div>
              <button type="button" className="primrybtn  v-button">
                Validate
              </button>
            </div>
          </div>

          {/* <div className="col-md-3">
            <div className="form-bx">
              <label>
                <select
                  // ref={applicantYearRef}
                  name="applicantYear"
                  onChange={(e) => {
                    changeHandelForm(e);
                  }}
                >
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                  <option value="2021">2021</option>
                  <option value="2020">2020</option>
                  <option value="2019">2019</option>
                  <option value="2018">2018</option>
                  <option value="2017">2017</option>
                </select>
                <span className="sspan"></span>
              </label>
            </div>
          </div> */}
          <div className="col-md-3 text-right"></div>
        </div>
      </div>
      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">Application Date</label>

        <div className="form-bx">
          {/* <label> */}
          <DatePicker
            closeOnScroll={(e) => e.target === document}
            selected={applicationDetail?.applicationDate ? applicationDetail?.applicationDate : startDate}
            onChange={(date) => setStartDate(date)}
            peekNextMonth 
            showMonthDropdown
            maxDate={new Date()}
            showYearDropdown
            dropdownMode="select"  
          />

          <span className="sspan"></span>
          {/* </label> */}
        </div>
      </div>
      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">Application Type</label>

        <div className="form-bx">
          <label>
            <select
              ref={applicationTypeRef}
              name="applicationTypeID"
              onChange={(e) => {
                changeHandelForm(e);
              }}
              className={
                errors.applicationTypeID  
                  ? "error"
                  : ""
              }
            >
              <option value="">Select Application Type</option>
              {applicationType?.map((item, ind) => {
                return (
                  <option key={item.id} value={item.id} selected={applicationDetail?.applicationTypeID === item?.id }>
                    {item.name}
                  </option>
                );
              })}
            </select>
            <span className="sspan"></span>
            {errors.applicationTypeID  ? (
              <small className="errormsg">{errors.applicationTypeID}</small>
            ) : (
              ""
            )}
          </label>
        </div>
      </div>
      {/* end form-bx  */}

      <div className="row">
        <div className="col-md-6">
          <div className="inner_form_new">
            <label className="controlform">Currency</label>

            <div className="form-bx">
              <label>
                <select
                  ref={currencyRef}
                  name="currency"
                  onChange={(e) => {
                    changeHandelForm(e);
                  }}
                  className={
                    errors.currency && applicationDetail?.currency === ""
                      ? "error"
                      : ""
                  }
                >
                  <option value="">Select Currency</option>
                  {currency?.map((cur, ind) => {
                    return (
                      <option key={cur.id} value={cur.id} selected={applicationDetail?.currency === cur.id}>
                        {cur.currencyCode}
                      </option>
                    );
                  })}
                </select>
                <span className="sspan"></span>
                {errors.currency && applicationDetail.currency === "" ? (
                  <small className="errormsg">{errors.currency}</small>
                ) : (
                  ""
                )}
              </label>
            </div>
          </div>
          {/* end form-bx  */}
        </div>

        <div className="col-md-3">
          <div className="inner_form_new-sm">
            <label className="controlform-sm">Amount</label>

            <div className="form-bx-sm">
              <label>
                <input
                  ref={amountRef}
                  type="number"
                  min={0}
                  name="amount"
                  onChange={(e) => {
                    changeHandelForm(e);
                  }}
                  value={applicationDetail?.amount}
                  placeholder="Amount"
                  className={
                    errors.amount && applicationDetail?.amount === "" ? "error" : ""
                  }
                />
                <span className="sspan"></span>
                {errors.amount && applicationDetail?.amount === "" ? (
                  <small className="errormsg">{errors.amount}</small>
                ) : (
                  ""
                )}
              </label>
            </div>
          </div>
          {/* end form-bx  */}
        </div>

        <div className="col-md-3">
          <div className="inner_form_new-sm">
            <label className="controlform-sm">Rate</label>

            <div className="form-bx-sm">
              <label>
                <input
                  ref={rateRef}
                  type="text"
                  name="rate"
                  value={applicationDetail?.currency ? curRate ? curRate : applicationDetail.rate : "Rate"}
                  onChange={(e) => {
                    changeHandelForm(e);
                  }}
                  placeholder="Rate"
                  disabled
                />
                <span className="sspan"></span>
              </label>
            </div>
          </div>
          {/* end form-bx  */}
        </div>
      </div>

      <div className="inner_form_new ">
        <label className="controlform">USD Equivalent</label>

        <div className="form-bx">
          <label>
            <input
              ref={usdEquivalentRef}
              type="text"
              name="usdEquivalent"
              value={
                applicationDetail?.currency && applicationDetail?.amount
                  ? convertedRate == NaN ? applicationDetail?.usdEquivalent : convertedRate.toFixed(2)
                  : "USD Equivalent"
              }
              onChange={(e) => {
                changeHandelForm(e);
              }}
              placeholder="USD Equivalent"
              disabled
            />
            <span className="sspan"></span>
          </label>
        </div>
      </div>
      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">
          Related Exchange Control Reference Number
        </label>

        <div className="form-bx">
          <label>
            <input
              ref={relatedexchangeControlNumberRef}
              type="text"
              min={0}
              name="relatedexchangeControlNumber"
              onChange={(e) => {
                changeHandelForm(e);
              }}
              placeholder="Related Exchange Control Reference Number"
              className={
                errors.relatedexchangeControlNumber 
                  ? "error text-uppercase"
                  : "text-uppercase"
              }
            />
            <span className="sspan"></span>
            {errors.relatedexchangeControlNumber   ? (
              <small className="errormsg">
                {errors.relatedexchangeControlNumber}
              </small>
            ) : (
              ""
            )}
          </label>
        </div>
      </div>
      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">Sector</label>

        <div className="form-bx">
          <label>
            <select
              ref={sectorRef}
              name="sector"
              onChange={(e) => {
                changeHandelForm(e);
              }}
              className={
                errors.sector && applicationDetail?.sector === "" ? "error" : ""
              }
            >
              <option value="">Select Sector</option>
              {sectorData?.map((item, ind) => {
                return (
                  <option key={item.id} value={item.id} selected={applicationDetail?.sector === item.id}>
                    {item.sectorName}
                  </option>
                );
              })}
            </select>
            <span className="sspan"></span>
            {errors.sector && applicationDetail?.sector === "" ? (
              <small className="errormsg">{errors.sector}</small>
            ) : (
              ""
            )}
          </label>
        </div>
      </div>
      {/* end form-bx  */}

      <div className="inner_form_new">
        <label className="controlform">Subsector</label>

        <div className="form-bx">
          <label>
            <select
              ref={subsectorRef}
              name="subSector"
              onChange={(e) => {
                changeHandelForm(e);
              }}
              disabled={applicationDetail.sector === "" ? true : false}
              className={
                errors.subSector  ? "error" : ""
              }
            >
              <option>Subsector</option>
              {subsectorData?.map((item, index) => {
                return (
                  <option key={item.id} value={item.id} selected={applicationDetail?.subSector == item.id}>
                    {item.subSectorName}
                  </option>
                );
              })}
            </select>
            <span className="sspan"></span>
            {errors.subSector ? (
              <small className="errormsg">{errors.subSector}</small>
            ) : (
              ""
            )}
          </label>
        </div>
      </div>
      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">Applicant Comments</label>

        <div className="form-bx">
          <label>
            <textarea
              ref={applicantCommentsRef}
              name="applicantComment"
              onChange={(e) => {
                changeHandelForm(e);
              }}
              placeholder="Applicant Comments"
              className={
                errors.applicantComment 
                  ? "error"
                  : ""
              }
              value={applicationDetail.applicantComment}
            />
            <span className="sspan"></span>
            {errors.applicantComment   ? (
              <small className="errormsg">{errors.applicantComment}</small>
            ) : (
              ""
            )}
          </label>
        </div>
      </div>
      {/* end form-bx  */}

      <div className="inner_form_new ">
        <label className="controlform">Submit to Bank Supervisor</label>

        <input
          type="checkbox"
          className="mt-4" 
          onChange={(e) => {
            HandelSupervisorcheck(e);
          }} 
          checked={checkSupervisor }
        />
      </div>
      {/* end form-bx  */}

      {checkSupervisor == true ? (
        <div className="inner_form_new ">
          <label className="controlform">Select Bank Supervisor</label>

          <div className="form-bx">
            <label>
              <select
                ref={assignedToRef}
                name="assignedTo"
                onChange={(e) => {
                  changeHandelForm(e);
                }}
                className={
                  errors.assignedTo
                    ? "error"
                    : ""
                }
              >
                <option value="">
                  Select Bank Supervisor
                </option>
                {Supervisors?.map((item, index) => {
                  return (
                    <option key={index} value={item?.userID} selected={item.userID == applicationDetail?.assignedTo}>
                      {item.name}
                    </option>
                  );
                })}
              </select>
              <span className="sspan"></span>
              {errors.assignedTo ? (
                <small className="errormsg">{errors.assignedTo}</small>
              ) : (
                ""
              )}
            </label>
          </div>
        </div>
      ) : (
        ""
      )}
      {/* end form-bx  */}

      <h5 className="section_top_subheading mt-2">Attachments</h5>

      {attachmentData?.map((items, index) => {
        return (
          <div className="attachemt_form-bx" key={items.id}>
            <label>
              <i className="bi bi-forward"></i>
              {items.name}
            </label>
            <div className="browse-btn">
              Browse{" "}
              <input
                type="file"
                onChange={(e) => handleFileChange(e, items.id)}
              />
            </div>
            <span className="filename">
              {files.find((f) => f.id === items?.id)?.file?.name ||
                "No file chosen"}
            </span>
          </div>
        );
      })}

      {otherfiles.map((file, index) => (
        <div key={"other" + (index + 1)} className="attachemt_form-bx">
          <label>
            <i className="bi bi-forward"></i> Other File {index + 1}
          </label>
          <div className="browse-btn">
            Browse{" "}
            <input
              type="file"
              onChange={(e) => {
                handleFileChange(e, "other" + (index + 1));
                handleOthrefile(e, "other" + (index + 1));
              }}
            />
          </div>
          <span className="filename">
            {files.find((f) => f.id === "other" + (index + 1))?.file?.name ||
              "No file chosen"}
          </span>
        </div>
      ))}

      {attachmentData?.length ? (
        <button
          type="button"
          className="addmore-btn"
          onClick={(e) => handleAddMore(e)}
        >
          {" "}
          Add More File{" "}
        </button>
      ) : (
        ""
      )}

      <div className="form-footer mt-5 mb-3">
        <button
          type="reset"
          onClick={(e) => {
            ResetHandleData(e);
          }}
          className="register"
        >
          Reset
        </button>
        <button
          type="button"
          onClick={(e) => {
            HandleSubmit(e);
          }}
          className="login"
        >
          Submit
        </button>
      </div>
    </form>
  </>
  )
}

export default ExportDashboardEditDetails

import React, { useEffect, useState } from 'react';
import logo from "../Logo_T.png";
import { Link, useNavigate } from 'react-router-dom';
import {Helmet} from "react-helmet";
import AuthUser from './AuthUser';
import { APIURL } from '../constant';
import { toast } from 'react-toastify'; 
import axios from 'axios';

const ChangePassword = () => { 

    const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [toastDisplayed, setToastDisplayed] = useState(false);

 
  
  const navigate = useNavigate();

  const  resetForm = async (e)=>{

e.preventDefault()

    await axios.post(APIURL + 'User/ChangePassword',{
        UserName: email,
        Password:password
    }).then((res)=>{
        // console.log("resresresresresres",res.data.responseCode)
        if(res.data.responseCode == '200'){ 
            setToastDisplayed(true)
            if(toastDisplayed == true){
                alert()
                toast.success(res.data.responseMessage)
            }
            setTimeout(() => {
                navigate('/')
            }, 1200);
        }
        else{
            setToastDisplayed(true)
            if(toastDisplayed == true){

                toast.warning(res.data.responseMessage)
            }
        }
    })
    .catch((error)=>{
        console.log(error)
    })

  }

  const currentUrl = window.location.href;
  const urlParts = currentUrl.split("/");
  const lastUrlPart = urlParts[urlParts.length - 1];

  console.log("lastUrlPart", lastUrlPart)
  useEffect(() => {
    if (toastDisplayed) {
        setTimeout(() => {
            setToastDisplayed(false)
        }, 1500);
    }
}, [toastDisplayed])

useEffect(()=>{
  const resetpasswordToken = localStorage.getItem("resetpasswordtoken")
  if(resetpasswordToken !== lastUrlPart){
    navigate("/")
  }

},[1500])
 

  return (
     <>
     
     <Helmet>  <title>Reset Password</title>  </Helmet>

<div className='login_outer '>
  <div className='login_inner login-max-width'>
    <div className='login_inner_header'>
      <Link to='/'><img src={logo} /> </Link>
      <h3>Document Management System</h3>
    </div>

    <div className='login_form '>
      <h5>Reset Password</h5>
    </div>

    <div className='login_form_panel'>
      <div className='form-bx mb-5'>
        <label>
          <input type="email" className="form-control" placeholder="Enter email"
            onChange={(e) => {setEmail(e.target.value)}}
            id="email" />

          <span className='sspan'></span>
        </label>
      </div>
      <div className='form-bx'>
        <label>
          <input type="password" className="form-control" placeholder="Enter password" onChange={(e) =>{ setPassword(e.target.value)}} id="pwd" />
          <span className='sspan'></span>
        </label>
      </div>
 

      <div className='form-footer'>
      {/* <Link to='/' className='register'>Back</Link> */}
        <button className='login' type="button" onClick={(e)=>resetForm(e)} disabled= {toastDisplayed}>{toastDisplayed == true ? 'Please Wait..' : 'Submit'}</button>
      </div>




    </div>

  </div>

</div>
     
     </>
  )
}

export default ChangePassword

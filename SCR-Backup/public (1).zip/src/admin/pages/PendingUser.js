import React from 'react'
import { Link } from "react-router-dom";
import { Helmet } from 'react-helmet';
import AdminDashboardLayout from '../components/AdminDashboardLayout';

const PendingUser = () => {
  return (
    <>
      <Helmet>  <title>Dashboard</title>  </Helmet>
      <AdminDashboardLayout>
        <nav>
          <ol className="breadcrumb">
            <li className="breadcrumb-item"><a href="index.html">Home</a></li>
            <li className="breadcrumb-item active">PendingUser</li>
          </ol>
        </nav>
        

        <section className="section dashboard">

         
          <div className='row'>
            <div className='col-md-12'>
              <div className='datatable'>
                <h4 className='section_top_heading'>PendingUser</h4>

                <p>No record</p>

              </div>
            </div>
          </div>

        </section>
      </AdminDashboardLayout>
    </>
  )
}

export default PendingUser

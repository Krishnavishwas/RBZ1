import React from 'react'
import { Helmet } from 'react-helmet'
import AdminDashboardLayout from './AdminDashboardLayout'

const EditorTemplate = () =>{
    return (
        <>
        <Helmet><title>Editor</title></Helmet>
        <AdminDashboardLayout>
        <nav>
                    <ol className="breadcrumb">
                        <li className="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li className="breadcrumb-item active">Bank</li>
                    </ol>
                </nav>
                
                <section className="section dashboard adminDashboard">

                   

                    <div className='row'>
                        <div className='col-md-12'>
                            <div className='datatable'>
                               
                               <div className='row'>
                                <div className='col-md-5'>
                                <div className='form-box-outer'>
                                            <h2 className='mt-0'>Top Banner</h2>

                                            <label>Logo <small>(.png, .jpg, .jpeg)</small></label>
                                            <input type='file' className='form-control bx' name='bannerimage' accept='.png, .jpg, .jpeg' />
                                        </div>
                                <h2>Hello to welcome Editor left side </h2>
                                </div>
                                <div className='col-md-7'>
                                <h2>Hello to welcome Editor right side </h2>
                                </div>
                               </div>
                               
                            </div>
                        </div>
                    </div>

                </section>

      
        </AdminDashboardLayout>
        </>
    )
}

export default EditorTemplate